﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.5),
    on June 14, 2023, at 15:00
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.5'
expName = 'AUTonline'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\james\\Documents\\ZDesktop\\PhD\\Misc\\SfNC\\AUT\\AUTonline_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1536, 864], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "AUTinstrux" ---
intrux = visual.TextStim(win=win, name='intrux',
    text="For the next task, you'll be asked to come up with as many original and creative uses for objects as you can.\n\nThe goal is to come up with *creative ideas*, which are ideas that strike people as clever, unusual, interesting, uncommon, humorous, innovative, or different.\n\nYou will have 3 minutes to type as many CREATIVE USES for each object as you can. \nDo not write simply properties of the object, or words associated with the object, but actual uses.\n\nPress ENTER after each use, to write the next one.\n\nYou will be asked to type uses for 2 different objects. ",
    font='Arial',
    pos=(0, 0.1), height=0.035, wrapWidth=1.2, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
EntertoContinue = visual.TextStim(win=win, name='EntertoContinue',
    text='Press ENTER to continue',
    font='Arial',
    pos=(0, -.35), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "AUTblank" ---
text_5 = visual.TextStim(win=win, name='text_5',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.15, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "AUT" ---
AUTrespbox = visual.Rect(
    win=win, name='AUTrespbox',
    width=(0.5, 0.25)[0], height=(0.5, 0.25)[1],
    ori=0, pos=(0, -0.25), anchor='center',
    lineWidth=1,     colorSpace='rgb',  lineColor=[1,1,1], fillColor=[1,1,1],
    opacity=1, depth=0.0, interpolate=True)
InstruxAUT = visual.TextStim(win=win, name='InstruxAUT',
    text='Think of as many creative uses as you can\nfor the following word: ',
    font='Arial',
    pos=(0, .25), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
AUTResp = visual.TextStim(win=win, name='AUTResp',
    text='',
    font='Arial',
    pos=(0, -0.25), height=0.05, wrapWidth=0.48, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
AUTcueDisp = visual.TextStim(win=win, name='AUTcueDisp',
    text='',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
# Run 'Begin Experiment' code from AUTcode

import math

countdownStarted = False
CAPS=False
timeText_1 = visual.TextStim(win=win, name='timeText_1',
    text='',
    font='Arial',
    pos=(0.5, -0.3), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-5.0);
key_respAUT = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "AUTinstrux" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
_key_resp_2_allKeys = []
# Run 'Begin Routine' code from code
AUTtime=180
EscapeAllowed = True
win.mouseVisible = False
#js code that doesnt work:
#document.body.style.cursor=‘none’
# keep track of which components have finished
AUTinstruxComponents = [intrux, EntertoContinue, key_resp_2]
for thisComponent in AUTinstruxComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "AUTinstrux" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *intrux* updates
    if intrux.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        intrux.frameNStart = frameN  # exact frame index
        intrux.tStart = t  # local t and not account for scr refresh
        intrux.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(intrux, 'tStartRefresh')  # time at next scr refresh
        intrux.setAutoDraw(True)
    
    # *EntertoContinue* updates
    if EntertoContinue.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        EntertoContinue.frameNStart = frameN  # exact frame index
        EntertoContinue.tStart = t  # local t and not account for scr refresh
        EntertoContinue.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(EntertoContinue, 'tStartRefresh')  # time at next scr refresh
        EntertoContinue.setAutoDraw(True)
    
    # *key_resp_2* updates
    waitOnFlip = False
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=['return'], waitRelease=False)
        _key_resp_2_allKeys.extend(theseKeys)
        if len(_key_resp_2_allKeys):
            key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
            key_resp_2.rt = _key_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in AUTinstruxComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "AUTinstrux" ---
for thisComponent in AUTinstruxComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "AUTinstrux" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
AUTtrials = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('cond.xlsx'),
    seed=None, name='AUTtrials')
thisExp.addLoop(AUTtrials)  # add the loop to the experiment
thisAUTtrial = AUTtrials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisAUTtrial.rgb)
if thisAUTtrial != None:
    for paramName in thisAUTtrial:
        exec('{} = thisAUTtrial[paramName]'.format(paramName))

for thisAUTtrial in AUTtrials:
    currentLoop = AUTtrials
    # abbreviate parameter names if possible (e.g. rgb = thisAUTtrial.rgb)
    if thisAUTtrial != None:
        for paramName in thisAUTtrial:
            exec('{} = thisAUTtrial[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "AUTblank" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    AUTblankComponents = [text_5]
    for thisComponent in AUTblankComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "AUTblank" ---
    while continueRoutine and routineTimer.getTime() < 1.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_5* updates
        if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_5.frameNStart = frameN  # exact frame index
            text_5.tStart = t  # local t and not account for scr refresh
            text_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
            text_5.setAutoDraw(True)
        if text_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_5.tStartRefresh + 1-frameTolerance:
                # keep track of stop time/frame for later
                text_5.tStop = t  # not accounting for scr refresh
                text_5.frameNStop = frameN  # exact frame index
                text_5.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in AUTblankComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "AUTblank" ---
    for thisComponent in AUTblankComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.000000)
    
    # set up handler to look after randomisation of conditions etc
    AUTresps = data.TrialHandler(nReps=100, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='AUTresps')
    thisExp.addLoop(AUTresps)  # add the loop to the experiment
    thisAUTresp = AUTresps.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisAUTresp.rgb)
    if thisAUTresp != None:
        for paramName in thisAUTresp:
            exec('{} = thisAUTresp[paramName]'.format(paramName))
    
    for thisAUTresp in AUTresps:
        currentLoop = AUTresps
        # abbreviate parameter names if possible (e.g. rgb = thisAUTresp.rgb)
        if thisAUTresp != None:
            for paramName in thisAUTresp:
                exec('{} = thisAUTresp[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "AUT" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        AUTcueDisp.setText(cue)
        # Run 'Begin Routine' code from AUTcode
        shift_flag = False
        Resptext = ''
        RT1stKP=0
        #Resptext2=''
        RTLastKP=0
        
        if not countdownStarted:
            startTime=globalClock.getTime()
            #timeText="03:00"
            countdownStarted=True
            
        event.clearEvents('keyboard')
        key_respAUT.keys = []
        key_respAUT.rt = []
        _key_respAUT_allKeys = []
        # keep track of which components have finished
        AUTComponents = [AUTrespbox, InstruxAUT, AUTResp, AUTcueDisp, timeText_1, key_respAUT]
        for thisComponent in AUTComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "AUT" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *AUTrespbox* updates
            if AUTrespbox.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                AUTrespbox.frameNStart = frameN  # exact frame index
                AUTrespbox.tStart = t  # local t and not account for scr refresh
                AUTrespbox.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(AUTrespbox, 'tStartRefresh')  # time at next scr refresh
                AUTrespbox.setAutoDraw(True)
            
            # *InstruxAUT* updates
            if InstruxAUT.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                InstruxAUT.frameNStart = frameN  # exact frame index
                InstruxAUT.tStart = t  # local t and not account for scr refresh
                InstruxAUT.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(InstruxAUT, 'tStartRefresh')  # time at next scr refresh
                InstruxAUT.setAutoDraw(True)
            
            # *AUTResp* updates
            if AUTResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                AUTResp.frameNStart = frameN  # exact frame index
                AUTResp.tStart = t  # local t and not account for scr refresh
                AUTResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(AUTResp, 'tStartRefresh')  # time at next scr refresh
                AUTResp.setAutoDraw(True)
            if AUTResp.status == STARTED:  # only update if drawing
                AUTResp.setText(Resptext, log=False)
            
            # *AUTcueDisp* updates
            if AUTcueDisp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                AUTcueDisp.frameNStart = frameN  # exact frame index
                AUTcueDisp.tStart = t  # local t and not account for scr refresh
                AUTcueDisp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(AUTcueDisp, 'tStartRefresh')  # time at next scr refresh
                AUTcueDisp.setAutoDraw(True)
            # Run 'Each Frame' code from AUTcode
            keys = event.getKeys()
            n=len(keys)
            i=0
            
            
            ###Timer#####
            Diff=globalClock.getTime()-startTime
            timeRemaining = AUTtime-math.floor(Diff/1) #this gives us a whole number for time 
            #remaining, using floor not round since we do not want the seconds to update except when the timeremaining crosses an actual whole integer
            Minutes = int(timeRemaining/60.0) # the integer number of minutes
            Seconds = int(timeRemaining - (Minutes * 60.0))
            if Minutes<10:
                minstring='0' + str(Minutes)
            else:
                minstring=str(Minutes)
            if Seconds<10:
                secstring='0' + str(Seconds)
            else:
                secstring=str(Seconds)
            timeText = minstring + ':' + secstring # create a string of characters representing the time
            
            
            ###### Text entry #####
            while i < n: # len(keys):
                if keys[i] == 'return' and len(Resptext)>=1 or timeRemaining<= 0:
                    continueRoutine = False
                    break
                elif keys[i] == 'escape' and EscapeAllowed == True:
                    continueRoutine = False
                    core.quit()
                    break
                elif keys[i] == 'space' :
                    Resptext += " "
                    i += 1
                elif keys[i] == 'backspace' :
                    Resptext = Resptext[:-1]
                    i += 1
                elif keys[i] == 'capslock' :
                    if CAPS==True:
                        CAPS= False
                    elif CAPS==False:
                        CAPS=True
                    i += 1
                elif keys[i] == 'period'and len(Resptext) < 80:
                    Resptext += "."
                    i += 1
                elif keys[i] == 'minus' and len(Resptext) < 80:
                    Resptext += "-"
                    i += 1
                elif keys[i] == 'comma' and len(Resptext) < 80: 
                    Resptext += ","
                    i = i + 1
                elif keys[i] in ['lshift', 'rshift']:
                    shift_flag = True
                    i = i + 1
                elif keys[i] == 'semicolon' and len(Resptext) < 80:
                    if shift_flag == False:
                        Resptext += ";"
                    else:
                        Resptext += ":"
                        shift_flag = False
                    i += 1
                elif keys[i] == 'apostrophe' and len(Resptext) < 80:
                    if shift_flag == False:
                        Resptext += "'"
                    else:
                        Resptext += '"'
                    i += 1
                elif keys[i] == 'slash' and len(Resptext) < 80:
                    if shift_flag == False:
                        Resptext += "/"
                    else:
                        Resptext += '?'
                        shift_flag = False
                    i = i + 1
                elif keys[i] == '1' and len(Resptext) < 80 and shift_flag == True:
                    Resptext += "!"
                    shift_flag = False
                    i = i + 1
                else:
                    if len(Resptext) < 80 and len(keys[i])==1:
                        Key=keys[i]
                        if CAPS or shift_flag:
                            Resptext += Key.upper()
                            shift_flag=False
                        else:
                            Resptext += Key
                    i += 1
            
            if timeRemaining <= 0:
                AUTresps.finished = True
                continueRoutine = False
            
            """
            Resptext2= ' ' + Resptext + '|'
            if Diff%2 > 1:
                AUTResp_2.color="white"
            else:
                AUTResp_2.color="black"
            """
            
            # *timeText_1* updates
            if timeText_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                timeText_1.frameNStart = frameN  # exact frame index
                timeText_1.tStart = t  # local t and not account for scr refresh
                timeText_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(timeText_1, 'tStartRefresh')  # time at next scr refresh
                timeText_1.setAutoDraw(True)
            if timeText_1.status == STARTED:  # only update if drawing
                timeText_1.setText(timeText, log=False)
            
            # *key_respAUT* updates
            waitOnFlip = False
            if key_respAUT.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_respAUT.frameNStart = frameN  # exact frame index
                key_respAUT.tStart = t  # local t and not account for scr refresh
                key_respAUT.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_respAUT, 'tStartRefresh')  # time at next scr refresh
                key_respAUT.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_respAUT.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_respAUT.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_respAUT.status == STARTED and not waitOnFlip:
                theseKeys = key_respAUT.getKeys(keyList=None, waitRelease=False)
                _key_respAUT_allKeys.extend(theseKeys)
                if len(_key_respAUT_allKeys):
                    key_respAUT.keys = [key.name for key in _key_respAUT_allKeys]  # storing all keys
                    key_respAUT.rt = [key.rt for key in _key_respAUT_allKeys]
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in AUTComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "AUT" ---
        for thisComponent in AUTComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # Run 'End Routine' code from AUTcode
        #extract the 1st and last key presses
        if len(key_respAUT.rt)>0:
            RT1stKP=key_respAUT.rt[0]
            RTLastKP=key_respAUT.rt[-1]
        
        #save the data for this trial
        thisExp.addData("AUTresp", Resptext)
        thisExp.addData("AUTRT1stKP", RT1stKP)
        thisExp.addData("AUTRTLastKP", RTLastKP)
        Resptext = ''
        
        
        # check responses
        if key_respAUT.keys in ['', [], None]:  # No response was made
            key_respAUT.keys = None
        AUTresps.addData('key_respAUT.keys',key_respAUT.keys)
        if key_respAUT.keys != None:  # we had a response
            AUTresps.addData('key_respAUT.rt', key_respAUT.rt)
        # the Routine "AUT" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 100 repeats of 'AUTresps'
    
    thisExp.nextEntry()
    
# completed 1 repeats of 'AUTtrials'


# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
