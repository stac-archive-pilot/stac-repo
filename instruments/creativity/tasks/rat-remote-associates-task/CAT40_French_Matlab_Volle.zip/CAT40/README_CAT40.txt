# CAT — Combination of Associates tasks

**Authors:** Matthieu Bernard; adapted for Memowave by the CreaTeam
**Last updated:** 27/02/2026 (Alizée Lopez-Persem)
**Language:** MATLAB (Psychtoolbox-3, tested on MATLAB 2017a and 2018b, macOS; Matlab2024b, PC)
**Stimulus language:** French

**References:**
—

---

## Overview

The CAT is a computerised remote associates task that measures insight problem-solving. Participants are shown **three cue words** arranged in a triangle on screen and must find a **fourth word** that is semantically related to all three. After each answer, they report whether their solution came as a sudden **Euréka** moment (insight) or emerged through deliberate, step-by-step reasoning.

This version of the CAT task comprises a **training phase** (10 trials) followed by a **main task** (40 trials).

---

## Subtasks

### 1. Training phase — 10 trials

Participants complete 10 trials to familiarise themselves with the task format, the response procedure, and the Euréka judgement. Responses and Euréka judgements are recorded during this phase.

### 2. Main task — 40 trials

Participants complete 40 trials, randomly shuffled per participant. Items vary in difficulty:

- **P (Proche)** — easy triads with a straightforward linking word
- **D (Distant)** — harder triads requiring more remote semantic associations

A break is automatically triggered after 20 trials.

---

## Stimuli

- **40 French word triads** (main task), randomly shuffled per participant — `Lists/TAC/WordLists/TAC40_list_strictCorrect_memowave.csv`
- **10 training word triads** — `Lists/TAC/WordLists/TAC_training.csv`
- Each triad has a primary target answer (cible) and multiple accepted alternative responses (ciblebis columns)
- **Training word triads:** droit/palais/loi, songer/espérer/inventer, allumer/souffler/fermer, chasser/charger/coup, réussir/gloire/bataille, fort/seigneur/visite, peau/presser/enfoncer, cher/trésor/unique, décider/oser/accomplir, pain/culture/herbe

---

## Trial Structure

```
Three cue words displayed in triangle on screen (white on black)
    ↓
Participant thinks (minimum 0.5 s before response is accepted)
    ↓
Participant presses SPACEBAR when a word comes to mind
    ↓
Prompt "Réponse ?" — participant types their answer (5 s to type)
    ↓
ENTER to submit  |  Screen turns grey 2 s before time-out (30 s limit)
    ↓
Euréka question displayed as text (if answer was given)
"Est ce que votre reponse est apparue d'un coup, sans effort (Eureka) ?"
    ↓
V (oui) or N (non) — 4.5 s to respond
    ↓
ITI (0.5 s)
```

**Note:** If the participant does not press SPACEBAR within 30 seconds, the trial is counted as a timeout and 'NONE' is stored as the response. The Euréka question is not shown for timeout trials.

---

## Output Variables

Responses are saved per participant in `Results/<YYYYMMDD>_<StudyName>_<ParticipantCode>/` as `.mat` files containing an `Output_TAC` struct with the following fields:

- `Output_TAC.randseed` — random generator seed used to shuffle trials
- `Output_TAC.QEureka` — participant's initial Euréka experience response (V or N), collected during slide 12 of instructions
- `Output_TAC.ResTraining` — training phase data (cell array, one row per trial)
- `Output_TAC.ResTask` — main task data (cell array, one row per trial)

For `ResTraining` and `ResTask`, each row contains the original stimulus columns from the CSV, followed by response columns appended during the experiment:

| Column | Content |
|--------|---------|
| 1 | Trial name |
| 2 | Mot1 (cue word 1) |
| 3 | Mot2 (cue word 2) |
| 4 | Mot3 (cue word 3) |
| 5–16 | Correct answer(s) and accepted alternatives (from CSV) |
| 17 | Difficulty (P = proche/easy, D = distant/hard) |
| 18 | FGATmemowave flag (y = word used in FGAT list, n = not used) |
| 19 | Reaction time (display onset → SPACEBAR press, in seconds) |
| 20 | Gave answer in time? (1 = yes, 0 = timeout) |
| 21 | Typed response (uppercase string) |
| 22 | Typing duration (SPACEBAR → ENTER, in seconds; 0 if timeout) |
| 23 | Euréka RT (question onset → key press, in seconds; NaN if timeout trial) |
| 24 | Euréka gave answer? (1 = yes, 0 = timeout; NaN if timeout trial) |
| 25 | Euréka key pressed ('v', 'n', or 'NA'; NaN if timeout trial) |

One output file is created per session:
- `Results/<YYYYMMDD>_<StudyName>_<ParticipantCode>/<YYYYMMDD>_TAC_MEMOWAVE_<StudyName>_<ParticipantCode>.mat`

The file is saved and overwritten after every trial, providing crash recovery.

---

## Task Parameters

| Parameter | Value |
|-----------|-------|
| Think time before response window | 0.5 s |
| ITI (after response) | 0.5 s |
| Time limit — find word | 30 s |
| Grey-screen warning before timeout | 2 s before limit |
| Max typing time | 5 s |
| Euréka response time limit | 4.5 s |
| Number of training trials | 10 |
| Number of main task trials | 40 |
| Mid-task break after | 20 trials |
| Word colour | White [255 255 255] |
| Background colour (active) | Black [0 0 0] |
| Background colour (near timeout) | Grey [127 127 127] |
| Font size — cue words | 60 |
| Font size — Euréka question | 40 |
| Response keys — Euréka | V (oui), N (non) |

---

## File Structure

```
CAT40_Matlab_Psychotoolbox/
├── GUI_Creaflex.fig                       # Shared GUI for participant info entry (GUIDE)
├── GUI_Creaflex.m                         # Shared GUI code
├── README.md                              # This file
├── +MainTaskFct/
│   └── TAC_Main.m                         # Core task logic (entry point called by GUI)
├── +Parameters/
│   └── TAC_Parameters.m                   # All task settings (timing, colours, keys, etc.)
├── +DisplayFct/
│   ├── ScreenStart.m                      # Psychtoolbox window initialisation
│   ├── DisplayTrial_Resp.m                # Single-trial display and response collection
│   ├── DisplayWords.m                     # Word rendering on screen
│   ├── AskLimitTime.m                     # Time-limited keyboard input (with accent support)
│   └── display_instructions_crehackTAC.m  # Instruction slide display (JPG-based)
├── +OtherFct/
│   ├── Break.m                            # Mid-task break screen
│   ├── CheckCorrectNbrItem.m              # Validates list item count against parameters
│   ├── CreationFolderSaveData.m           # Creates timestamped output folder
│   └── KbCheck_accent.m                   # Keyboard input with French accent support
└── Lists/TAC/
    ├── Instructions/
    │   └── instructions/
    │       └── Diapositive1–16.JPG        # Instruction slides
    └── WordLists/
        ├── TAC40_list_strictCorrect_memowave.csv  # 40 main task word triads
        └── TAC_training.csv                        # 10 training word triads
```

---

## How to Run

1. Open MATLAB and set the working directory to the `CAT40_Matlab_Psychotoolbox/` folder.
2. Run `GUI_Creaflex.m` (do not open `GUI_Creaflex.fig`).
3. Enter the **study name** and **participant code** in the GUI fields.
4. Click the **TAC** button to launch the task.
5. The training phase (10 trials) runs automatically before the main task (40 trials).
6. Data are saved automatically to `Results/<YYYYMMDD>_<StudyName>_<ParticipantCode>/` after every trial.

**Requirements:** Psychtoolbox-3, MATLAB 2017a or later.

---

## Participant Instructions (exact text, French)

### Pre-training instructions — Slides 1 to 15

**Slide 01**
> Merci de participer à cette expérience !
>
> Le but du jeu est de deviner des mots à partir de mots indices

**Slide 02**
> Trois mots indices vont apparaitre, disposés en triangle à l'écran :
>
> L'objectif est de trouver un 4ème mot, relié d'une façon ou d'une autre, à chacun de ces mots indices.
>
> *(example words displayed on screen: Loi — Droit — Palais)*

**Slide 03**
> Trois mots indices vont apparaitre, disposés en triangle à l'écran :
>
> L'objectif est de trouver un 4ème mot, relié d'une façon ou d'une autre, à chacun de ces mots indices.
>
> La réponse peut être un verbe, un adjectif, un nom commun, mais pas un nom propre ni un mot composé.
>
> *(example words displayed on screen: Loi — Droit — Palais)*

**Slide 04**
> Vous disposez de 30 secondes pour trouver ce mot.
>
> Quand vous avez la réponse, appuyez sur la touche « Espace ».
>
> *(example words displayed on screen: Loi — Droit — Palais)*

**Slide 05**
> Vous disposez de 30 secondes pour trouver ce mot.
>
> Quand vous avez la réponse, appuyez sur la touche « Espace ».
>
> Quand le fond d'écran devient gris, il vous reste 2 secondes pour appuyer sur la touche « Espace »
>
> *(example words displayed on screen: Loi — Droit — Palais, grey background)*

**Slide 06**
> Quand vous appuyez sur Espace, le mot « réponse ? » s'affiche à l'écran.
>
> Vous disposerez alors de 5 secondes pour taper votre réponse sans aucun caractère spécial (pas besoin de mettre des accents).
>
> *(prompt displayed on screen: Réponse ?)*

**Slide 07**
> Quand vous appuyez sur Espace, le mot « réponse ? » s'affiche à l'écran.
>
> Vous disposerez alors de 5 secondes pour taper votre réponse sans aucun caractère spécial (pas besoin de mettre des accents).
>
> Ensuite, appuyez sur « Entrée » pour valider votre réponse.
>
> *(prompt displayed on screen: Réponse ?)*

**Slide 08**
> Il est important de réfléchir et de connaitre votre réponse AVANT d'appuyer sur la touche « Espace ».

**Slide 09**
> Ensuite, vous devez dire si oui ou non vous avez résolu le problème par un phénomène d'Euréka.
>
> C'est à dire si la solution vous est venue soudainement, comme une illumination.

**Slide 10**
> Ensuite, vous devez dire si oui ou non vous avez résolu le problème par un phénomène d'Euréka.
>
> C'est à dire si la solution vous est venue soudainement, comme une illumination.
>
> Ce phénomène est ressenti quand une solution vient à l'esprit d'un coup, sans effort.
>
> Il s'oppose à une résolution stratégique, ou par étapes progressives où sont testées plusieurs possibilités.

**Slide 11**
> La question porte donc sur l'expérience subjective que vous avez eu dans l'instant qui a précédé la réponse que vous avez donnée.

**Slide 12** *(response required: V or N)*
> La question porte donc sur l'expérience subjective que vous avez eu dans l'instant qui a précédé la réponse que vous avez donnée.
>
> Avez-vous déjà expérimenté ce phénomène ?
>
> Si oui, appuyez sur la touche « v »
> Si non, appuyez sur la touche « n »

**Slide 13**
> Ces deux manières de résoudre les devinettes ne sont pas incompatibles et sont toutes les deux autant valides.
>
> Il est possible qu'un euréka survienne après une recherche plus réfléchie, ou alors que vous pensiez être dans une impasse.

**Slide 14**
> Ces deux manières de résoudre les devinettes ne sont pas incompatibles et sont toutes les deux autant valides.
>
> Il est possible qu'un euréka survienne après une recherche plus réfléchie, ou alors que vous pensiez être dans une impasse.
>
> Pour répondre à la question « Euréka ? », vous disposerez de 5 secondes
>
> OUI : touche « V »
> NON : touche « N ».

**Slide 15**
> Faisons un petit entraînement…

---

### Pre-task instruction — Slide 16

**Slide 16**
> Avez-vous des questions ?
> Sinon, démarrons le test.
