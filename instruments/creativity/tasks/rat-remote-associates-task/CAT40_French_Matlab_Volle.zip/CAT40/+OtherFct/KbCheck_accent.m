function [reply] = KbCheck_accent(last)

clear KbCheck
FlushEvents;
% if ismac
%  codes_accents = [31 36 39 47  51 46 44    33 38 192 40      42   27 ];
% %                �  �  �  ^    m -  space '  �  �   return delete escape
%  codes_voyelles = [20 8 18 12 24];
% %                 a  e  i  o  u
% else
codes_accents = [50 55 48 221 77 54 32    52 57 52  13      8     27  ];
codes_voyelles = [65 69 73 79 85];
% end
% qwerty = 'qwertyuiopasdfghjklzxcvbnm';
qwerty = 'azertyuiopqsdfghjklwxcvbn';
azerty = 'azertyuiopqsdfghjklwxcvbn';

KbName('UnifyKeyNames');
get_second_char=0;
keyPressed = 0; % set this to zero until we receive a sensible keypress
while keyPressed == 0 % hang the system until a response is given
    keyIsDown='';
    keyCode=zeros(256,1);
    
    [ ~, ~, keyCode ] = KbCheck;
    
    
    if sum(keyCode)~=0
        keyPressed = find(keyCode);
        if keyPressed == codes_accents(1)
            reply='�';
        elseif keyPressed == codes_accents(2)
            reply='�';
        elseif keyPressed == codes_accents(3)
            reply='�';
        elseif keyPressed == codes_accents(4) %(^)
            get_second_char = 1;
        elseif keyPressed==codes_accents(5)
            reply='m';
        elseif keyPressed== codes_accents(6)
            reply='-';
        elseif keyPressed== codes_accents(7)
            reply=' ';
        elseif keyPressed== codes_accents(8)
            reply='''';
        elseif keyPressed== codes_accents(9)
            reply='�';
        elseif keyPressed== codes_accents(10)
            reply='�';
        elseif keyPressed== codes_accents(11)
            reply='Return';
        elseif keyPressed== codes_accents(12)
            reply='DELETE';
        elseif keyPressed== codes_accents(13)
            reply='ESCAPE';
            error('user pressed escape');
        else
            
            reply = KbName(keyPressed(1));
            
            if  ~isempty(strfind(azerty,reply))
                reply=azerty(strfind(qwerty,reply));
            else
                reply = '';
            end
            
        end
    end
end
FlushEvents('keyDown');

if get_second_char==1
    keyPressed2=0;
    while keyPressed2 == 0 % hang the system until a response is given
        
        [ ~, ~, keyCode2 ] = KbCheck;
        
        if sum(keyCode2)~=0
            if find(keyCode2)==codes_voyelles(1)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(2)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(4)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(3)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(5)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            else
                keyPressed2=0;
            end
            
        end
    end
end

if (strcmp(last,'�') && strcmp(reply,'a')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'e')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'o')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'i')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'u'))
    reply = '';
end

keyPressed3=0;
dd=0;
while keyPressed3 == 0 % hang the system until a response is given
    dd=dd+1;
    [ ~, ~, keyCode3] = KbCheck; % check for keypress
    if isempty(find(keyCode3))
        keyPressed3=1;
        
        break
    end
    try
        if find(keyCode3)~=find(keyCode)
            keyPressed3=1;
            
            break
        end
    end
    
    if exist('keyCode2','var')
        keyPressed3=1;
        
        FlushEvents;
        break
    end
    
    if strcmpi(reply,'Return')
        keyPressed3=1;
    end
    
end

