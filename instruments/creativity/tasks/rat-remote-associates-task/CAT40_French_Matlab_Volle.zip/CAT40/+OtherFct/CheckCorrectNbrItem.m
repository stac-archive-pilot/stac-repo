function CheckCorrectNbrItem(ListWords,NumberItems)

%%%%%%%%%%%%%%%%
% Version: 1
% Last Edited: 23/10/2018
% Author: Matthieu Bernard
% Contact: matthieubernard@outlook.com
%
%INPUT: - ListWords: List with the words of the current task
%       - NumberItems: The number of items that should be executed.
%%%%%%%%%%%%%%%%

%%
%Calculate the number of rows of the list
RealNbr=size(ListWords,1);

%Check if the number matched the number of items expected in the parameters
if RealNbr ~= NumberItems
    %If not, send an error message and stop the program
    error('The number of items specify in the Parameters do not match the length of the list! Need to change!')
end

end