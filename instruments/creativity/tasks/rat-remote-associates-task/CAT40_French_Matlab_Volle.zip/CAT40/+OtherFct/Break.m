function Break(window,ColorText,HowLongWaitSec)

%%%%%%%%%%%%%%%%
% Version: 1
% Last Edited: 23/10/2018
% Author: Matthieu Bernard
% Contact: matthieubernard@outlook.com
%
%INPUT: - window: The window in which the text should be display.
%       - ColorText: The colour of the text to display. [R G B]
%       - HowLongWaitSec: How many time before participant can start again
%
%Note: Need to have Psychtoolbox-3 installed.
%%%%%%%%%%%%%%%%

%%
%When the counter reach the threshold pause the task
%Display a text on the screen
TranfoMin=HowLongWaitSec;%/60;
PauseText=['Vous allez maintenant prendre une pause. Vous pourrez \n reprendre la tache dans ' num2str(TranfoMin) ' secondes.'];

%Ask the question to the participant if he gets a sudden response
DrawFormattedText(window, PauseText, 'center', 'center',ColorText);

%Flip to the screen
Screen('Flip', window);

%Wait for 1 seconds
WaitSecs(HowLongWaitSec);

PauseText2='Appuyez sur la barre "Espace" quand vous souhaitez continuer le test.';

%Ask the question to the participant if he gets a sudden response
DrawFormattedText(window, PauseText2, 'center', 'center',ColorText);

%Flip to the screen
Screen('Flip', window);

%Wait for 0.2 seconds
WaitSecs(0.2);

%Wait for input of the participant
KbWait;

end