%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           TAC_task
% Version: 1
% Last Edited: 23/10/2018
% Author: Matthieu Bernard
% Contact: matthieubernard@outlook.com
%
% Description; This script will start the TAC task where the participant
% will have to find a fourth word linking three cues words.
%
% Input files required:
%           - The list of the cues.
%           - The instructions text files
%           - The correct parameters in associated script.
%
% Required Psychtoolbox-3.
% Created on Matlab2017a and 2018b.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
%Loading parameters of GUI
load('TempOutputGUI.mat')
delete TempOutputGUI.mat
PN=OutputGUI.ParticipantNumber;
Initials=OutputGUI.Initials;

%Load parameters of the task
Parameters.TAC_Parameters;

%Shuffle the random seed
Seed_is = rng('shuffle');

%Import the list of the words and create a variable to contain it.
TempTAC_task=table2array(readtable([pathList 'TAC40_list_strictCorrect_memowave.csv'],'ReadVariableNames',true,'FileEncoding',EncodingTxT));
%Import the list of the training and create a variable to contain it.
TAC_training=table2array(readtable([pathList 'TAC_training.csv'],'ReadVariableNames',true,'FileEncoding',EncodingTxT));

%Check if the number of items in the list matched the number expected in
%the parameters
OtherFct.CheckCorrectNbrItem(TempTAC_task,NumberItemsTask);
OtherFct.CheckCorrectNbrItem(TAC_training,NumberITemsTrain);

%Shuffle the trials of the task
TAC_task = TempTAC_task(randperm(size(TempTAC_task,1)),:);

%Create screen display
DisplayFct.ScreenStart;

%Create ouput variables for the experiement.
Output_TAC=struct;

%Store the seed of the random generator in the output
Output_TAC.randseed=Seed_is;

%Create a folder with the data and the participants number
NameFolder=[DateString '_' PN '_' Initials];
Created=OtherFct.CreationFolderSaveData('Results',1,NameFolder);

%Silent the input from keyboard
ListenChar(2)
HideCursor(OutputScreen);

%    Screen('Preference','TextRenderer', 0)
%%
%Training

% %Display the instruction
% DisplayFct.Display_Instructions(InstructionScreensPart1,EncodingTxT,NormalColor,pathInstru,window,FontSizeInstruct)
% 
% %Ask the participants if has experienced eureka already
% Q_Eureka=DisplayFct.AskingInstructions(InstructionQuestion,EncodingTxT,NormalColor,pathInstru,window,LeftArrow,RightArrow,FontSizeInstruct);
% %Store the response in the output
% Output_TAC.QEureka=Q_Eureka;
% 
% %Display the instruction
% DisplayFct.Display_Instructions(InstructionScreensPart2,EncodingTxT,NormalColor,pathInstru,window,FontSizeInstruct);
ins_root='/Lists/TAC/Instructions/instructions/';
options.left_right={'LeftArrow','RightArrow'};
RestrictKeysForKbCheck([]);

options.diapo_num = 1:15;
[time_start,time_end,key_pressed,Q_Eureka]=DisplayFct.display_instructions_crehackTAC(window,windowRect,ins_root,options);
Output_TAC.QEureka=Q_Eureka;
%Define the number of columns are already stored in the training set
NumberCol_Train=size(TAC_training,2);


for WhichIterationTrain = 1:NumberITemsTrain
    
    %Store in a temporary variable, the current word to be display
    ListElements=TAC_training(WhichIterationTrain,2:4);
    %Display the trial and get the response of the participants
    TempOutput=DisplayFct.DisplayTrial_Resp(ListElements,window,LeftScreenPosition,RightScreenPosition,BottomScreenPosition,TopScreenPosition,FontSizeTrial,NormalColor,BackgroundWT,BackgroundNT,TimeThink,TimeITI,Time2Wait,TypeRespTrial,[],Key2EnableTask);
    %Display the eureka question
   if ~strcmp(TempOutput{3},'NONE')
    EurekaOutput=DisplayFct.DisplayTrial_Resp(QuestionInstruction,window,[],[],[],[],FontSizeEureka,NormalColor,BackgroundWT,BackgroundNT,TimeThink,TimeITI,Time2Wait_Q,TypeRespEureka,WhichChoice,Key2EnableEureka);
    else
    EurekaOutput=NaN;
    end
    %Get the size of both output variable and add them
    HowManyCol=length(TempOutput)+length(EurekaOutput);
    %Store the current response for the trial in a temporary variable
    TAC_training(WhichIterationTrain,NumberCol_Train+1:NumberCol_Train+HowManyCol)=[TempOutput,EurekaOutput];
    
    %Store the training responses in the output variable
    Output_TAC.ResTraining=TAC_training;
    
    %Save the responses in the newly created folder
    save([Created '/' DateString '_TAC_' PNType PN '_' Initials],'Output_TAC');
end


%%
%Task

%Display the instruction
% DisplayFct.Display_Instructions(InstructionScreensPart3,EncodingTxT,NormalColor,pathInstru,window,FontSizeInstruct)
options.diapo_num = 16;
[time_start,time_end,key_pressed,Q_Eureka]=DisplayFct.display_instructions_crehackTAC(window,windowRect,ins_root,options);
%Define the number of columns are already stored in the task set
NumberCol_Task=size(TAC_task,2);

for WhichIterationTask = 1:NumberItemsTask
    
    %Store in a temporary variable, the current word to be display
    ListElements=TAC_task(WhichIterationTask,2:4);
    %Display the trial and get the response of the participants
    TempOutput=DisplayFct.DisplayTrial_Resp(ListElements,window,LeftScreenPosition,RightScreenPosition,BottomScreenPosition,TopScreenPosition,FontSizeTrial,NormalColor,BackgroundWT,BackgroundNT,TimeThink,TimeITI,Time2Wait,TypeRespTrial,[],Key2EnableTask);
    %Display the eureka question
    if ~strcmp(TempOutput{3},'NONE')
        
        EurekaOutput=DisplayFct.DisplayTrial_Resp(QuestionInstruction,window,[],[],[],[],FontSizeEureka,NormalColor,BackgroundWT,BackgroundNT,TimeThink,TimeITI,Time2Wait_Q,TypeRespEureka,WhichChoice,Key2EnableEureka);
    else
        EurekaOutput=NaN;
    end
    
    %Get the size of both output variable and add them
    HowManyCol=length(TempOutput)+length(EurekaOutput);
    %Store the current response for the trial in a temporary variable
    TAC_task(WhichIterationTask,NumberCol_Task+1:NumberCol_Task+HowManyCol)=[TempOutput,EurekaOutput];
    
    %Store the training responses in the output variable
    Output_TAC.ResTask=TAC_task;
    
    %Save the responses in the newly created folder
    save([Created '/' DateString '_TAC_' PNType PN '_' Initials],'Output_TAC');
    
    %Launch a break after a certain amount of trials
    if WhichIterationTask==WhenPause
        OtherFct.Break(window,NormalColor,10)
    end
    Screen('Close')
end

%%

%Save the responses in the newly created folder
save([Created '/' DateString '_TAC_' PNType PN '_' Initials],'Output_TAC');

%Allow input again on command line
ListenChar(0)

% Clear the screen and finish the experiment
clearvars;
sca;
