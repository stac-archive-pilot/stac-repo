%%%%%%%%%%%TAC parameter

KbName('UnifyKeyNames');%Unify the keys across the different OS.

OutputScreen=0;%Define the output screen where everything will be drawn

CurrentDate = datetime('now'); %See the current date
DateString = datestr(CurrentDate,'yyyymmdd'); %Change the format of the current date
PNType='MEMOWAVE_'; %Define the number of the experiment

pathList='Lists/TAC/WordLists/';%Define where the list of words are stored
pathInstru='Lists/TAC/Instructions/';%Define where the instructions files are stored

EncodingCSV='UTF-8'; %Specify the encoding of the csv file
EncodingTxT='Macintosh';%Specify the encoding of the txt file

FontSizeInstruct=45; %Define the size of the font for the instructions
FontSizeTrial=60; %Define the size of the font for the cues words in the trials
FontSizeEureka=40; %Define the size of the font for the cues words in the trials
InstructionScreensPart1=[1;2;3;4;5]; %How many instruction display before training
InstructionQuestion=6; %Instruction asking if already experienced the eureka
InstructionScreensPart2=[7;8;9]; %How many instruction display before training
InstructionScreensPart3=10; %How many instruction display after training
TimeThink=0.5; %Define the time to think before to respond
TimeITI=0.5; %ITI before the next trial
Time2Wait=30; %How many seconds to wait for trial (always +1)
Time2Wait_Q=4.5; %How many seconds to wait for "eureka" (always +1)

NormalColor=[255 255 255]; %Define the normal color for the word display (white)
BackgroundWT= [0 0 0]; %Define the normal color for the background (black)
BackgroundNT=[127 127 127]; %Define the color for the background before the end of the trial (grey)

NumberITemsTrain=10; %Decide the number of training
NumberItemsTask=40; %Decide the number of trial

SpaceBar=KbName('SPACE'); %Obtain the key number of the space bar
VLetter=KbName('V'); %Obtain the key number of the letter V
NLetter=KbName('N'); %Obtain the key number of the letter N
LeftArrow=KbName('LeftArrow'); %Obtain the key number of the left arrow
RightArrow=KbName('RightArrow'); %Obtain the key number of the right arrow
Key2EnableTask=SpaceBar; %Decide which key are enable during the task
Key2EnableEureka=[VLetter NLetter]; %Decide which key are enable during the eureka

TypeRespTrial='keyboard'; %Decide the way to respond for the participants during the task
TypeRespEureka='Choice'; %Decide the way to respond for the participants during the eureka
WhichChoice={'v','n'}; %Set up which key will be use for the choice in the eureka

StartAnswer=5; %Define the columns where the first "answer" is store
EndAnswer=16; %Define the columns where the last "answer" is store %28
WhereAnswer=21; %Define the columns where answer from participant is store %32
WhereScore=27; %Define the columns where answer from participant is store %38
WhereEureka=24; %Define the columns where answer from participant is store %35

WhenPause=NumberItemsTask/2;%Decide the number of trial before to pause, if not integer, round the number to superior

QuestionInstruction='Est ce que votre reponse est apparue d''un coup, sans effort (Eureka)? \n \n Repondez avec les touches V (oui) ou N (non) du clavier.';%Question ask during the eureka

%HowMuchItem=8;
