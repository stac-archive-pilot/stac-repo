﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2020.2.8),
    on January 10, 2023, at 14:55
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2020.2.8'
expName = 'RATonline'  # from the Builder filename that created this script
expInfo = {'participant': '99', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\james\\Documents\\ZDesktop\\PhD\\Misc\\SfNC\\OSF for RAT\\oldRAT\\RATonline_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1536, 864], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "_settings"
_settingsClock = core.Clock()
#Remote Associates Test (RAT)
#Written by James Lloyd-Cox for the Society for the Neuroscience of Creativity
#This is meant as an example of how to code the RAT in Psychopy, and is not meant to represent the "best" way to do it
#Feel free to edit or change the experiment in any way

#import libraries
import math
import random

#initiate variables
CAPS=False

#SETTINGS
# Time (in seconds) that trials last:
RATtime=30; 
# character limit for RAT text entry:
charlim=25


win.mouseVisible = False


# Initialize components for Routine "RAT_instrux"
RAT_instruxClock = core.Clock()
RATintrux = visual.TextStim(win=win, name='RATintrux',
    text="For the next task, you'll be shown 3 unrelated cue words, and you must find a 4th word that relates to all 3 words shown. See the example below:\n\n\nCues:\n\nCHOCOLATE       FORTUNE       TIN \n\n\nSolution:\n\nCOOKIE\n\n\nCookie is the correct answer because it relates to all 3 cue words.\n",
    font='Arial',
    pos=(0, 0.1), height=0.03, wrapWidth=1.2, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
EntertoContinue = visual.TextStim(win=win, name='EntertoContinue',
    text='Press ENTER to continue',
    font='Arial',
    pos=(0, -.3), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_2 = keyboard.Keyboard()

# Initialize components for Routine "RATinstrux_2"
RATinstrux_2Clock = core.Clock()
RATintrux2 = visual.TextStim(win=win, name='RATintrux2',
    text='You will have 30 seconds per problem to think of an answer.\n\nAs soon as you think you have the correct answer, type it in the box and press ENTER.\n\nYou will then see the next problem.\n\nPress ENTER now to see some practise trials.',
    font='Arial',
    pos=(0, 0.1), height=0.03, wrapWidth=1.2, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
EntertoContinue_2 = visual.TextStim(win=win, name='EntertoContinue_2',
    text='Press ENTER to continue',
    font='Arial',
    pos=(0, -.3), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_3 = keyboard.Keyboard()

# Initialize components for Routine "RATblank"
RATblankClock = core.Clock()
text_5 = visual.TextStim(win=win, name='text_5',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.15, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "RAT"
RATClock = core.Clock()
RATrespbox = visual.Rect(
    win=win, name='RATrespbox',
    width=(0.33, 0.13)[0], height=(0.33, 0.13)[1],
    ori=0, pos=(0, -0.2),
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=[1,1,1], fillColorSpace='rgb',
    opacity=1, depth=0.0, interpolate=True)
InstruxRAT = visual.TextStim(win=win, name='InstruxRAT',
    text='Think of a word that relates to all of these words:',
    font='Arial',
    pos=(0, .25), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);


RATResp = visual.TextStim(win=win, name='RATResp',
    text='default text',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=0.3, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
timer_1 = visual.TextStim(win=win, name='timer_1',
    text='default text',
    font='Arial',
    pos=(0.5, -0.35), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);
key_resp = keyboard.Keyboard()
RATcueDisp = visual.TextStim(win=win, name='RATcueDisp',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);
RATcueDisp_3 = visual.TextStim(win=win, name='RATcueDisp_3',
    text='default text',
    font='Arial',
    pos=(-0.3, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-7.0);
RATcueDisp_4 = visual.TextStim(win=win, name='RATcueDisp_4',
    text='default text',
    font='Arial',
    pos=(0.3, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-8.0);

# Initialize components for Routine "RATpracAns"
RATpracAnsClock = core.Clock()
RATcueDisp_2 = visual.TextStim(win=win, name='RATcueDisp_2',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
RATcueDisp_5 = visual.TextStim(win=win, name='RATcueDisp_5',
    text='default text',
    font='Arial',
    pos=(-0.3, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
RATcueDisp_6 = visual.TextStim(win=win, name='RATcueDisp_6',
    text='default text',
    font='Arial',
    pos=(0.3, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
text = visual.TextStim(win=win, name='text',
    text='default text',
    font='Arial',
    pos=(0, -0.2), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
InstruxRAT_2 = visual.TextStim(win=win, name='InstruxRAT_2',
    text='Correct Answer:',
    font='Arial',
    pos=(0, .2), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "RATinstrux_3"
RATinstrux_3Clock = core.Clock()
RATintrux3 = visual.TextStim(win=win, name='RATintrux3',
    text='That is the end of the practise trials. There will now be 10 real trials. You will no longer be shown the correct answer.\n\nRemember: the solution word must relate to all 3 cue words.\n\nYou will have 30 seconds per problem to think of an answer.\n\nAs soon as you think you have the correct answer, type it in the box and press ENTER.',
    font='Arial',
    pos=(0, 0.1), height=0.03, wrapWidth=1.2, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
EntertoContinue_3 = visual.TextStim(win=win, name='EntertoContinue_3',
    text='Press ENTER to continue',
    font='Arial',
    pos=(0, -.3), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_5 = keyboard.Keyboard()

# Initialize components for Routine "RATblank"
RATblankClock = core.Clock()
text_5 = visual.TextStim(win=win, name='text_5',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.15, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "RAT"
RATClock = core.Clock()
RATrespbox = visual.Rect(
    win=win, name='RATrespbox',
    width=(0.33, 0.13)[0], height=(0.33, 0.13)[1],
    ori=0, pos=(0, -0.2),
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=[1,1,1], fillColorSpace='rgb',
    opacity=1, depth=0.0, interpolate=True)
InstruxRAT = visual.TextStim(win=win, name='InstruxRAT',
    text='Think of a word that relates to all of these words:',
    font='Arial',
    pos=(0, .25), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);


RATResp = visual.TextStim(win=win, name='RATResp',
    text='default text',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=0.3, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
timer_1 = visual.TextStim(win=win, name='timer_1',
    text='default text',
    font='Arial',
    pos=(0.5, -0.35), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);
key_resp = keyboard.Keyboard()
RATcueDisp = visual.TextStim(win=win, name='RATcueDisp',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);
RATcueDisp_3 = visual.TextStim(win=win, name='RATcueDisp_3',
    text='default text',
    font='Arial',
    pos=(-0.3, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-7.0);
RATcueDisp_4 = visual.TextStim(win=win, name='RATcueDisp_4',
    text='default text',
    font='Arial',
    pos=(0.3, 0), height=0.07, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-8.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "_settings"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
_settingsComponents = []
for thisComponent in _settingsComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
_settingsClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "_settings"-------
while continueRoutine:
    # get current time
    t = _settingsClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=_settingsClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in _settingsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "_settings"-------
for thisComponent in _settingsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "_settings" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "RAT_instrux"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
_key_resp_2_allKeys = []
# keep track of which components have finished
RAT_instruxComponents = [RATintrux, EntertoContinue, key_resp_2]
for thisComponent in RAT_instruxComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
RAT_instruxClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "RAT_instrux"-------
while continueRoutine:
    # get current time
    t = RAT_instruxClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=RAT_instruxClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *RATintrux* updates
    if RATintrux.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        RATintrux.frameNStart = frameN  # exact frame index
        RATintrux.tStart = t  # local t and not account for scr refresh
        RATintrux.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(RATintrux, 'tStartRefresh')  # time at next scr refresh
        RATintrux.setAutoDraw(True)
    
    # *EntertoContinue* updates
    if EntertoContinue.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        EntertoContinue.frameNStart = frameN  # exact frame index
        EntertoContinue.tStart = t  # local t and not account for scr refresh
        EntertoContinue.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(EntertoContinue, 'tStartRefresh')  # time at next scr refresh
        EntertoContinue.setAutoDraw(True)
    
    # *key_resp_2* updates
    waitOnFlip = False
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=['return'], waitRelease=False)
        _key_resp_2_allKeys.extend(theseKeys)
        if len(_key_resp_2_allKeys):
            key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
            key_resp_2.rt = _key_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in RAT_instruxComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "RAT_instrux"-------
for thisComponent in RAT_instruxComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "RAT_instrux" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "RATinstrux_2"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_3.keys = []
key_resp_3.rt = []
_key_resp_3_allKeys = []
# keep track of which components have finished
RATinstrux_2Components = [RATintrux2, EntertoContinue_2, key_resp_3]
for thisComponent in RATinstrux_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
RATinstrux_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "RATinstrux_2"-------
while continueRoutine:
    # get current time
    t = RATinstrux_2Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=RATinstrux_2Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *RATintrux2* updates
    if RATintrux2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        RATintrux2.frameNStart = frameN  # exact frame index
        RATintrux2.tStart = t  # local t and not account for scr refresh
        RATintrux2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(RATintrux2, 'tStartRefresh')  # time at next scr refresh
        RATintrux2.setAutoDraw(True)
    
    # *EntertoContinue_2* updates
    if EntertoContinue_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        EntertoContinue_2.frameNStart = frameN  # exact frame index
        EntertoContinue_2.tStart = t  # local t and not account for scr refresh
        EntertoContinue_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(EntertoContinue_2, 'tStartRefresh')  # time at next scr refresh
        EntertoContinue_2.setAutoDraw(True)
    
    # *key_resp_3* updates
    waitOnFlip = False
    if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        key_resp_3.frameNStart = frameN  # exact frame index
        key_resp_3.tStart = t  # local t and not account for scr refresh
        key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_3.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_3.getKeys(keyList=['return'], waitRelease=False)
        _key_resp_3_allKeys.extend(theseKeys)
        if len(_key_resp_3_allKeys):
            key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
            key_resp_3.rt = _key_resp_3_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in RATinstrux_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "RATinstrux_2"-------
for thisComponent in RATinstrux_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "RATinstrux_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
RATpractrials = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('RATPraccues.xlsx'),
    seed=None, name='RATpractrials')
thisExp.addLoop(RATpractrials)  # add the loop to the experiment
thisRATpractrial = RATpractrials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisRATpractrial.rgb)
if thisRATpractrial != None:
    for paramName in thisRATpractrial:
        exec('{} = thisRATpractrial[paramName]'.format(paramName))

for thisRATpractrial in RATpractrials:
    currentLoop = RATpractrials
    # abbreviate parameter names if possible (e.g. rgb = thisRATpractrial.rgb)
    if thisRATpractrial != None:
        for paramName in thisRATpractrial:
            exec('{} = thisRATpractrial[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "RATblank"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    #This code ensures that the cue words are presented
    # in a random order
    
    CueString=[Cue1,Cue2,Cue3]
    # we want the cues in a random order
    random.shuffle(CueString)
    
    
    # keep track of which components have finished
    RATblankComponents = [text_5]
    for thisComponent in RATblankComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    RATblankClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "RATblank"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = RATblankClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=RATblankClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_5* updates
        if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_5.frameNStart = frameN  # exact frame index
            text_5.tStart = t  # local t and not account for scr refresh
            text_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
            text_5.setAutoDraw(True)
        if text_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_5.tStartRefresh + 1-frameTolerance:
                # keep track of stop time/frame for later
                text_5.tStop = t  # not accounting for scr refresh
                text_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_5, 'tStopRefresh')  # time at next scr refresh
                text_5.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RATblankComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "RATblank"-------
    for thisComponent in RATblankComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "RAT"-------
    continueRoutine = True
    # update component parameters for each repeat
    ##initiate variables
    #is shift pressed?
    shift_flag = False
    #set response text as empty
    Resptext = ''
    
    #set 1st and last key press times
    RT1stKP=0
    RTLastKP=0
    
    #start time for countdown/ trial timer
    startTime=globalClock.getTime()
    
        
    event.clearEvents('keyboard')
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    RATcueDisp.setText(CueString[0])
    RATcueDisp_3.setText(CueString[1])
    RATcueDisp_4.setText(CueString[2])
    # keep track of which components have finished
    RATComponents = [RATrespbox, InstruxRAT, RATResp, timer_1, key_resp, RATcueDisp, RATcueDisp_3, RATcueDisp_4]
    for thisComponent in RATComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    RATClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "RAT"-------
    while continueRoutine:
        # get current time
        t = RATClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=RATClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *RATrespbox* updates
        if RATrespbox.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATrespbox.frameNStart = frameN  # exact frame index
            RATrespbox.tStart = t  # local t and not account for scr refresh
            RATrespbox.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATrespbox, 'tStartRefresh')  # time at next scr refresh
            RATrespbox.setAutoDraw(True)
        
        # *InstruxRAT* updates
        if InstruxRAT.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            InstruxRAT.frameNStart = frameN  # exact frame index
            InstruxRAT.tStart = t  # local t and not account for scr refresh
            InstruxRAT.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(InstruxRAT, 'tStartRefresh')  # time at next scr refresh
            InstruxRAT.setAutoDraw(True)
        keys = event.getKeys()
        n=len(keys)
        i=0
        
        ###Timer#####
        Diff=globalClock.getTime()-startTime
        timeRemaining = RATtime-math.floor(Diff) #this gives us a whole number for time 
        #remaining, using floor not round since we do not want the seconds to update except when the timeremaining crosses an actual whole integer
        Minutes = int(timeRemaining/60.0) # the integer number of minutes
        Seconds = int(timeRemaining - (Minutes * 60.0))
        #convert the above numbers into strings in the right format
        if Minutes<10:
            minstring='0' + str(Minutes)
        else:
            minstring=str(Minutes)
        if Seconds<10:
            secstring='0' + str(Seconds)
        else:
            secstring=str(Seconds)
        timeText = minstring + ':' + secstring # create a string of characters representing the time
        
        
        ###### Text entry #####
        while i < n: # len(keys):
            #process each key depending on what it is
            if keys[i] == 'return' and len(Resptext)>=1 or timeRemaining<= 0:
                RTLastKP=Diff
                continueRoutine = False
                break
            elif keys[i] == 'escape' and EscapeAllowed == True:
                continueRoutine = False
                core.quit()
                break
            elif keys[i] == 'space' :
                Resptext += " "
                i += 1
            elif keys[i] == 'backspace' :
                Resptext = Resptext[:-1]
                i += 1
            elif keys[i] == 'capslock' :
                if CAPS==True:
                    CAPS= False
                elif CAPS==False:
                    CAPS=True
                i += 1
            elif keys[i] == 'period'and len(Resptext) < charlim:
                Resptext += "."
                i += 1
            elif keys[i] == 'minus' and len(Resptext) < charlim:
                Resptext += "-"
                i += 1
            elif keys[i] == 'comma' and len(Resptext) < charlim: 
                Resptext += ","
                i = i + 1
            elif keys[i] in ['lshift', 'rshift']:
                shift_flag = True
                i = i + 1
            elif keys[i] == 'semicolon' and len(Resptext) < charlim:
                if shift_flag == False:
                    Resptext += ";"
                else:
                    Resptext += ":"
                    shift_flag = False
                i += 1
            elif keys[i] == 'apostrophe' and len(Resptext) < charlim:
                if shift_flag == False:
                    Resptext += "'"
                else:
                    Resptext += '"'
                i += 1
            elif keys[i] == 'slash' and len(Resptext) < charlim:
                if shift_flag == False:
                    Resptext += "/"
                else:
                    Resptext += '?'
                    shift_flag = False
                i = i + 1
            elif keys[i] == '1' and len(Resptext) < charlim and shift_flag == True:
                Resptext += "!"
                shift_flag = False
                i = i + 1
            else:
                if len(Resptext) < charlim and len(keys[i])==1:
                    Key=keys[i]
                    if CAPS or shift_flag:
                        Resptext += Key.upper()
                        shift_flag=False
                    else:
                        Resptext += Key
                i += 1
        
        
        if timeRemaining <= 0:
            continueRoutine = False
         
        
        # *RATResp* updates
        if RATResp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            RATResp.frameNStart = frameN  # exact frame index
            RATResp.tStart = t  # local t and not account for scr refresh
            RATResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATResp, 'tStartRefresh')  # time at next scr refresh
            RATResp.setAutoDraw(True)
        if RATResp.status == STARTED:  # only update if drawing
            RATResp.setText(Resptext)
        
        # *timer_1* updates
        if timer_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            timer_1.frameNStart = frameN  # exact frame index
            timer_1.tStart = t  # local t and not account for scr refresh
            timer_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(timer_1, 'tStartRefresh')  # time at next scr refresh
            timer_1.setAutoDraw(True)
        if timer_1.status == STARTED:  # only update if drawing
            timer_1.setText(timeText)
        
        # *key_resp* updates
        waitOnFlip = False
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=None, waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = [key.name for key in _key_resp_allKeys]  # storing all keys
                key_resp.rt = [key.rt for key in _key_resp_allKeys]
        
        # *RATcueDisp* updates
        if RATcueDisp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp.frameNStart = frameN  # exact frame index
            RATcueDisp.tStart = t  # local t and not account for scr refresh
            RATcueDisp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp.setAutoDraw(True)
        
        # *RATcueDisp_3* updates
        if RATcueDisp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp_3.frameNStart = frameN  # exact frame index
            RATcueDisp_3.tStart = t  # local t and not account for scr refresh
            RATcueDisp_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp_3, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp_3.setAutoDraw(True)
        
        # *RATcueDisp_4* updates
        if RATcueDisp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp_4.frameNStart = frameN  # exact frame index
            RATcueDisp_4.tStart = t  # local t and not account for scr refresh
            RATcueDisp_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp_4, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp_4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RATComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "RAT"-------
    for thisComponent in RATComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    #extract the 1st and last key presses
    if len(key_resp.rt)>0:
        RT1stKP=key_resp.rt[0]
        RTLastKP=key_resp.rt[-1]
    
    #save the data for this trial
    thisExp.addData("RATresp", Resptext)
    thisExp.addData("RT1stKP", RT1stKP)
    thisExp.addData("RTLastKP", RTLastKP)
    Resptext = ''
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    RATpractrials.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        RATpractrials.addData('key_resp.rt', key_resp.rt)
    # the Routine "RAT" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "RATpracAns"-------
    continueRoutine = True
    routineTimer.add(3.000000)
    # update component parameters for each repeat
    RATcueDisp_2.setText(CueString[0])
    RATcueDisp_5.setText(CueString[1])
    RATcueDisp_6.setText(CueString[2])
    text.setText(Answer)
    # keep track of which components have finished
    RATpracAnsComponents = [RATcueDisp_2, RATcueDisp_5, RATcueDisp_6, text, InstruxRAT_2]
    for thisComponent in RATpracAnsComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    RATpracAnsClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "RATpracAns"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = RATpracAnsClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=RATpracAnsClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *RATcueDisp_2* updates
        if RATcueDisp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp_2.frameNStart = frameN  # exact frame index
            RATcueDisp_2.tStart = t  # local t and not account for scr refresh
            RATcueDisp_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp_2, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp_2.setAutoDraw(True)
        if RATcueDisp_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > RATcueDisp_2.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                RATcueDisp_2.tStop = t  # not accounting for scr refresh
                RATcueDisp_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(RATcueDisp_2, 'tStopRefresh')  # time at next scr refresh
                RATcueDisp_2.setAutoDraw(False)
        
        # *RATcueDisp_5* updates
        if RATcueDisp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp_5.frameNStart = frameN  # exact frame index
            RATcueDisp_5.tStart = t  # local t and not account for scr refresh
            RATcueDisp_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp_5, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp_5.setAutoDraw(True)
        if RATcueDisp_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > RATcueDisp_5.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                RATcueDisp_5.tStop = t  # not accounting for scr refresh
                RATcueDisp_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(RATcueDisp_5, 'tStopRefresh')  # time at next scr refresh
                RATcueDisp_5.setAutoDraw(False)
        
        # *RATcueDisp_6* updates
        if RATcueDisp_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp_6.frameNStart = frameN  # exact frame index
            RATcueDisp_6.tStart = t  # local t and not account for scr refresh
            RATcueDisp_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp_6, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp_6.setAutoDraw(True)
        if RATcueDisp_6.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > RATcueDisp_6.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                RATcueDisp_6.tStop = t  # not accounting for scr refresh
                RATcueDisp_6.frameNStop = frameN  # exact frame index
                win.timeOnFlip(RATcueDisp_6, 'tStopRefresh')  # time at next scr refresh
                RATcueDisp_6.setAutoDraw(False)
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
                text.setAutoDraw(False)
        
        # *InstruxRAT_2* updates
        if InstruxRAT_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            InstruxRAT_2.frameNStart = frameN  # exact frame index
            InstruxRAT_2.tStart = t  # local t and not account for scr refresh
            InstruxRAT_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(InstruxRAT_2, 'tStartRefresh')  # time at next scr refresh
            InstruxRAT_2.setAutoDraw(True)
        if InstruxRAT_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > InstruxRAT_2.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                InstruxRAT_2.tStop = t  # not accounting for scr refresh
                InstruxRAT_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(InstruxRAT_2, 'tStopRefresh')  # time at next scr refresh
                InstruxRAT_2.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RATpracAnsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "RATpracAns"-------
    for thisComponent in RATpracAnsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    RATpractrials.addData('text.started', text.tStartRefresh)
    RATpractrials.addData('text.stopped', text.tStopRefresh)
    thisExp.nextEntry()
    
# completed 1 repeats of 'RATpractrials'


# ------Prepare to start Routine "RATinstrux_3"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_5.keys = []
key_resp_5.rt = []
_key_resp_5_allKeys = []
# keep track of which components have finished
RATinstrux_3Components = [RATintrux3, EntertoContinue_3, key_resp_5]
for thisComponent in RATinstrux_3Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
RATinstrux_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "RATinstrux_3"-------
while continueRoutine:
    # get current time
    t = RATinstrux_3Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=RATinstrux_3Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *RATintrux3* updates
    if RATintrux3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        RATintrux3.frameNStart = frameN  # exact frame index
        RATintrux3.tStart = t  # local t and not account for scr refresh
        RATintrux3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(RATintrux3, 'tStartRefresh')  # time at next scr refresh
        RATintrux3.setAutoDraw(True)
    
    # *EntertoContinue_3* updates
    if EntertoContinue_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        EntertoContinue_3.frameNStart = frameN  # exact frame index
        EntertoContinue_3.tStart = t  # local t and not account for scr refresh
        EntertoContinue_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(EntertoContinue_3, 'tStartRefresh')  # time at next scr refresh
        EntertoContinue_3.setAutoDraw(True)
    
    # *key_resp_5* updates
    waitOnFlip = False
    if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.tStart = t  # local t and not account for scr refresh
        key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_5.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_5.getKeys(keyList=['return'], waitRelease=False)
        _key_resp_5_allKeys.extend(theseKeys)
        if len(_key_resp_5_allKeys):
            key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
            key_resp_5.rt = _key_resp_5_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in RATinstrux_3Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "RATinstrux_3"-------
for thisComponent in RATinstrux_3Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "RATinstrux_3" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
RATtrials = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('RATcues.xlsx'),
    seed=None, name='RATtrials')
thisExp.addLoop(RATtrials)  # add the loop to the experiment
thisRATtrial = RATtrials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisRATtrial.rgb)
if thisRATtrial != None:
    for paramName in thisRATtrial:
        exec('{} = thisRATtrial[paramName]'.format(paramName))

for thisRATtrial in RATtrials:
    currentLoop = RATtrials
    # abbreviate parameter names if possible (e.g. rgb = thisRATtrial.rgb)
    if thisRATtrial != None:
        for paramName in thisRATtrial:
            exec('{} = thisRATtrial[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "RATblank"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    #This code ensures that the cue words are presented
    # in a random order
    
    CueString=[Cue1,Cue2,Cue3]
    # we want the cues in a random order
    random.shuffle(CueString)
    
    
    # keep track of which components have finished
    RATblankComponents = [text_5]
    for thisComponent in RATblankComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    RATblankClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "RATblank"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = RATblankClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=RATblankClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_5* updates
        if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_5.frameNStart = frameN  # exact frame index
            text_5.tStart = t  # local t and not account for scr refresh
            text_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
            text_5.setAutoDraw(True)
        if text_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_5.tStartRefresh + 1-frameTolerance:
                # keep track of stop time/frame for later
                text_5.tStop = t  # not accounting for scr refresh
                text_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_5, 'tStopRefresh')  # time at next scr refresh
                text_5.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RATblankComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "RATblank"-------
    for thisComponent in RATblankComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "RAT"-------
    continueRoutine = True
    # update component parameters for each repeat
    ##initiate variables
    #is shift pressed?
    shift_flag = False
    #set response text as empty
    Resptext = ''
    
    #set 1st and last key press times
    RT1stKP=0
    RTLastKP=0
    
    #start time for countdown/ trial timer
    startTime=globalClock.getTime()
    
        
    event.clearEvents('keyboard')
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    RATcueDisp.setText(CueString[0])
    RATcueDisp_3.setText(CueString[1])
    RATcueDisp_4.setText(CueString[2])
    # keep track of which components have finished
    RATComponents = [RATrespbox, InstruxRAT, RATResp, timer_1, key_resp, RATcueDisp, RATcueDisp_3, RATcueDisp_4]
    for thisComponent in RATComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    RATClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "RAT"-------
    while continueRoutine:
        # get current time
        t = RATClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=RATClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *RATrespbox* updates
        if RATrespbox.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATrespbox.frameNStart = frameN  # exact frame index
            RATrespbox.tStart = t  # local t and not account for scr refresh
            RATrespbox.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATrespbox, 'tStartRefresh')  # time at next scr refresh
            RATrespbox.setAutoDraw(True)
        
        # *InstruxRAT* updates
        if InstruxRAT.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            InstruxRAT.frameNStart = frameN  # exact frame index
            InstruxRAT.tStart = t  # local t and not account for scr refresh
            InstruxRAT.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(InstruxRAT, 'tStartRefresh')  # time at next scr refresh
            InstruxRAT.setAutoDraw(True)
        keys = event.getKeys()
        n=len(keys)
        i=0
        
        ###Timer#####
        Diff=globalClock.getTime()-startTime
        timeRemaining = RATtime-math.floor(Diff) #this gives us a whole number for time 
        #remaining, using floor not round since we do not want the seconds to update except when the timeremaining crosses an actual whole integer
        Minutes = int(timeRemaining/60.0) # the integer number of minutes
        Seconds = int(timeRemaining - (Minutes * 60.0))
        #convert the above numbers into strings in the right format
        if Minutes<10:
            minstring='0' + str(Minutes)
        else:
            minstring=str(Minutes)
        if Seconds<10:
            secstring='0' + str(Seconds)
        else:
            secstring=str(Seconds)
        timeText = minstring + ':' + secstring # create a string of characters representing the time
        
        
        ###### Text entry #####
        while i < n: # len(keys):
            #process each key depending on what it is
            if keys[i] == 'return' and len(Resptext)>=1 or timeRemaining<= 0:
                RTLastKP=Diff
                continueRoutine = False
                break
            elif keys[i] == 'escape' and EscapeAllowed == True:
                continueRoutine = False
                core.quit()
                break
            elif keys[i] == 'space' :
                Resptext += " "
                i += 1
            elif keys[i] == 'backspace' :
                Resptext = Resptext[:-1]
                i += 1
            elif keys[i] == 'capslock' :
                if CAPS==True:
                    CAPS= False
                elif CAPS==False:
                    CAPS=True
                i += 1
            elif keys[i] == 'period'and len(Resptext) < charlim:
                Resptext += "."
                i += 1
            elif keys[i] == 'minus' and len(Resptext) < charlim:
                Resptext += "-"
                i += 1
            elif keys[i] == 'comma' and len(Resptext) < charlim: 
                Resptext += ","
                i = i + 1
            elif keys[i] in ['lshift', 'rshift']:
                shift_flag = True
                i = i + 1
            elif keys[i] == 'semicolon' and len(Resptext) < charlim:
                if shift_flag == False:
                    Resptext += ";"
                else:
                    Resptext += ":"
                    shift_flag = False
                i += 1
            elif keys[i] == 'apostrophe' and len(Resptext) < charlim:
                if shift_flag == False:
                    Resptext += "'"
                else:
                    Resptext += '"'
                i += 1
            elif keys[i] == 'slash' and len(Resptext) < charlim:
                if shift_flag == False:
                    Resptext += "/"
                else:
                    Resptext += '?'
                    shift_flag = False
                i = i + 1
            elif keys[i] == '1' and len(Resptext) < charlim and shift_flag == True:
                Resptext += "!"
                shift_flag = False
                i = i + 1
            else:
                if len(Resptext) < charlim and len(keys[i])==1:
                    Key=keys[i]
                    if CAPS or shift_flag:
                        Resptext += Key.upper()
                        shift_flag=False
                    else:
                        Resptext += Key
                i += 1
        
        
        if timeRemaining <= 0:
            continueRoutine = False
         
        
        # *RATResp* updates
        if RATResp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            RATResp.frameNStart = frameN  # exact frame index
            RATResp.tStart = t  # local t and not account for scr refresh
            RATResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATResp, 'tStartRefresh')  # time at next scr refresh
            RATResp.setAutoDraw(True)
        if RATResp.status == STARTED:  # only update if drawing
            RATResp.setText(Resptext)
        
        # *timer_1* updates
        if timer_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            timer_1.frameNStart = frameN  # exact frame index
            timer_1.tStart = t  # local t and not account for scr refresh
            timer_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(timer_1, 'tStartRefresh')  # time at next scr refresh
            timer_1.setAutoDraw(True)
        if timer_1.status == STARTED:  # only update if drawing
            timer_1.setText(timeText)
        
        # *key_resp* updates
        waitOnFlip = False
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=None, waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = [key.name for key in _key_resp_allKeys]  # storing all keys
                key_resp.rt = [key.rt for key in _key_resp_allKeys]
        
        # *RATcueDisp* updates
        if RATcueDisp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp.frameNStart = frameN  # exact frame index
            RATcueDisp.tStart = t  # local t and not account for scr refresh
            RATcueDisp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp.setAutoDraw(True)
        
        # *RATcueDisp_3* updates
        if RATcueDisp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp_3.frameNStart = frameN  # exact frame index
            RATcueDisp_3.tStart = t  # local t and not account for scr refresh
            RATcueDisp_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp_3, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp_3.setAutoDraw(True)
        
        # *RATcueDisp_4* updates
        if RATcueDisp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RATcueDisp_4.frameNStart = frameN  # exact frame index
            RATcueDisp_4.tStart = t  # local t and not account for scr refresh
            RATcueDisp_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RATcueDisp_4, 'tStartRefresh')  # time at next scr refresh
            RATcueDisp_4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RATComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "RAT"-------
    for thisComponent in RATComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    #extract the 1st and last key presses
    if len(key_resp.rt)>0:
        RT1stKP=key_resp.rt[0]
        RTLastKP=key_resp.rt[-1]
    
    #save the data for this trial
    thisExp.addData("RATresp", Resptext)
    thisExp.addData("RT1stKP", RT1stKP)
    thisExp.addData("RTLastKP", RTLastKP)
    Resptext = ''
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    RATtrials.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        RATtrials.addData('key_resp.rt', key_resp.rt)
    # the Routine "RAT" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'RATtrials'


# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
