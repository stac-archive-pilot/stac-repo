
NormalColor=[255 255 255]; %Define the normal color for the word display (white)
BackgroundWT= [0 0 0]; %Define the normal color for the background (black)
BackgroundNT=[127 127 127]; %Define the color for the background before the end of the trial (grey)
