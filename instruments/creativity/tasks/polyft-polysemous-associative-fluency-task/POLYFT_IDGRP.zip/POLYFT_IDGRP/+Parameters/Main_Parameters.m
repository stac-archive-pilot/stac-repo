%%%%%%%%%%%Part1 parameter

KbName('UnifyKeyNames');%Unify the keys across the different OS.
OutputScreen=0;%Define the output screen where everything will be drawn

CurrentDate = datetime('now'); %See the current date
DateString = datestr(CurrentDate,'yyyymmdd'); %Change the format of the current date
PNType='POLYFT_'; %Define the number of the experiment

pathInstru=['Lists/Main/Instructions/' char(Language) '/'];%Define where the instructions files are stored
Passa_Params=readtable("Params_table.xlsx",'Sheet',mode,'ReadRowNames',true);


if ~exist('PN','var')
    Initials='NP';
    PN='000';
else
    load('working_data.mat');
end


FontSizeInstruct=45; %Define the size of the font for the instructions
FontSizeTrial=60; %Define the size of the font for the cues words in the trials
TimeThink=0.5; %Define the time to think before to respond
TimeITI=0.5; %ITI before the next trial
Time2Wait=15; %Specify time for participant to answer the trial 

NormalColor=[255 255 255]; %Define the normal color for the word display (white)
BackgroundWT= [0 0 0]; %Define the normal color for the background (black)
BackgroundNT=[127 127 127]; %Define the color for the background before the end of the trial (grey)

InstructionScreens_Main=[strcat(pathInstru,"Debut/"), ...
                         strcat(pathInstru,"Pause/"),...
                         strcat(pathInstru,"Fin/"),...
                         strcat(pathInstru,"Transition/"),...
                         strcat(pathInstru,"Numero/"),...
                         strcat(pathInstru,"Reprise/")];

InstructionScreens_Training= strcat(pathInstru,"Training/");
EncodingFile='UTF-8'; %Specify the encoding of the txt file
EncodingInstruction='UTF-8'; %Specify the encoding of the instruction file
