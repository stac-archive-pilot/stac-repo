
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com

% Required Psychtoolbox-3.

% References:
%Ovando-Tellez et al Communication Biology 2023
%Ovando-Tellez, Vigreux et al., Imaging Neurosciences 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%
load('working_data');
%Load parameters of the task
OtherFct.GetParameters;
LimitTime=1000;

dx=fix(screenXpixels/8);
dy=fix(screenYpixels/15);
clr=[NormalColor; [217 83 25]];

grp_colors=hsv(10)*255;
grp_pos=[];

cube_side=fix(screenYpixels/30);
space=fix(screenYpixels/120);
outline=fix(space/2);

for line=1:2
    for col=1:5
        grp_pos(:,5*(line-1)+col)=[dx+(col-1-(col>5)*5)*(cube_side+space); 2*dy+(line-1)*(cube_side+space); dx+(col-(col>5)*5)*(cube_side)+(col-1-(col>5)*5)*space; 2*dy+(line)*cube_side+(line-1)*space];
    end
end

grp_mid_x= grp_pos(1,:)+cube_side/2;
grp_mid_y=grp_pos(2,:)+cube_side/2;
grp_pos_outline=[grp_pos(1,:)-outline;grp_pos(2,:)-outline;grp_pos(3,:)+outline;grp_pos(4,:)+outline];

Screen('TextSize',window,25);

keys=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];
keys=upper(keys);
LimitTime=Time2Wait;

if ~exist('Answers','var')
    data_shuffled=unique(data_list.target);
    data_shuffled=Shuffle(data_shuffled);

    Answers=data_list;
    Answers.grp=NaN(height(data_list),1);
end

%Display the instruction
DisplayFct.Display_Instructions_Images(window,pathInstru);
DisplayFct.Display_Instructions_Images(window,strcat(InstructionScreens_Training,"1"));

resps=["panthère" "tigre" "souris" "rat" "perroquet"  "lion" "lionne" "serpent" "baleine"  "dauphin"  "orque"  "cachalot" ];
ShowCursor

w_colors=zeros(length(resps),3)+grp_colors(1,:);
r=1:length(resps);
y=3*dy + dy*(r-fix((r-1)/10)*10);
x=dx*(fix((r-1)/10)+1);
firstit=0;
validated=0;


while  validated==0
    grp=ones(length(w_colors),1);
    current_color=grp_colors(1,:);
    w_colors=zeros(length(resps),3)+NormalColor;
    idx_col=1;
    nextw=0;
    current_idx=1;

    while nextw==0

        Screen('FillRect',window,[0 0 0])
        Screen('FillRect',window,[255 255 255], grp_pos_outline(:,current_idx));
        for c=1:length(grp_colors)
            Screen('FillRect',window,grp_colors(c,:), grp_pos(:,c));
        end

        DrawFormattedText(window, ['ENTRAINEMENT \n Selectionner une couleur en cliquant sur un carré, puis colorez le mot en cliquant dessus. \n Les mots du meme groupe doivent etre de la meme couleur.'],dx,dy,NormalColor)
        DrawFormattedText(window, 'Cliquez ici pour valider votre sélection',dx,14*dy,NormalColor)

        for rep=1:length(resps)
            disp_rep=resps{rep};
            DrawFormattedText(window, [char(string(rep)) '- ' char(disp_rep)],x(rep),y(rep),w_colors(rep,:));
        end
        t=Screen('Flip', window, 0 ,1);

        if firstit==0
            t0=t;
            firstit=1;
        end
        ok=0;

        while ok==0
            [clicks,cx,cy,whichButton]=GetClicks(window,[],LimitTime+t0);
            if cy > (13.75*dy) &&  ~any(all(w_colors== NormalColor,2))
                nextw=1;
                ok=1;
            else
                idx_rep=find(abs(x-cx)<dx*0.45 & min(abs(x-cx))==abs(x-cx) & abs(y-cy)<dy*0.45 & min(abs(y-cy))==abs(y-cy));

                idx_col=find(abs(grp_mid_x-cx)<dx*0.45 & min(abs(grp_mid_x-cx))==abs(grp_mid_x-cx) & abs(grp_mid_y-cy)<dy*0.45 & min(abs(grp_mid_y-cy))==abs(grp_mid_y-cy));

                if ~isempty(idx_col)
                    current_color=grp_colors(idx_col,:);
                    current_idx=idx_col;
                    ok=1;
                end

                if ~isempty(idx_rep) 
                    w_colors(idx_rep,:)= current_color;
                    ok=1;
                end

            end
        end
    end

    for c=1:length(grp_colors)
        grp(all(w_colors==grp_colors(c,:),2))=c;
    end
    

    if (length(find([1; abs(diff(grp))>0] == [1 0 1 0 1 1 0 1 1 0 0 0]')) <10) || all(w_colors(1,:)~= w_colors(6,:)) 
        DisplayFct.Display_Instructions_Images(window,strcat(InstructionScreens_Training,"3"));
    else
        validated=1;
    end

end
DisplayFct.Display_Instructions_Images(window,strcat(InstructionScreens_Training,"2"));



for trg=status.test:length(data_shuffled)
    
    DisplayFct.FixationCross(TimeIB,NormalColor,window,screenXpixels, screenYpixels,xCenter, yCenter);
    
    RestrictKeysForKbCheck([32 65:90 97:122])
    Screen('FillRect',window,[0 0 0])
    ShowCursor
    
   
    resps=data_list.response(strcmp(data_list.target,data_shuffled(trg)));

   
    r=1:length(resps);
    y=3*dy + dy*(r-fix((r-1)/10)*10);
    x=dx*(fix((r-1)/10)+1);
    firstit=0;
    validated=0;
    nextw=0;

    firstit=0;
    
    current_color=grp_colors(1,:);
    w_colors=zeros(length(resps),3)+NormalColor;
    idx_col=1;
    nextw=0;
    current_idx=1;

    while nextw==0
        Screen('FillRect',window,[0 0 0])
        Screen('FillRect',window,[255 255 255], grp_pos_outline(:,current_idx));
        for c=1:length(grp_colors)
            Screen('FillRect',window,grp_colors(c,:), grp_pos(:,c));
        end

        DrawFormattedText(window, ['Voici vos réponses pour le mot "' data_shuffled{trg} '" \n Les mots d un meme groupe doivent etre de la meme couleur.'],dx,dy,NormalColor)
        DrawFormattedText(window, 'Cliquez ici pour valider votre sélection',dx,14*dy,NormalColor)
        
        for rep=1:length(resps)
            disp_rep=resps{rep};
            DrawFormattedText(window, [char(string(rep)) '- ' char(disp_rep)],x(rep),y(rep),w_colors(rep,:));
        end
        t=Screen('Flip', window, 0 ,1);
        if firstit==0
            t0=t;
            firstit=1;
        end
        ok=0;
        while ok==0
            [clicks,cx,cy,whichButton]=GetClicks(window,[],LimitTime+t0);
            if cy > (13.75*dy) && ~any(all(w_colors== NormalColor,2))
                nextw=1;
                ok=1;
            else
                idx_rep=find(abs(x-cx)<dx*0.45 & min(abs(x-cx))==abs(x-cx) & abs(y-cy)<dy*0.45 & min(abs(y-cy))==abs(y-cy));

                idx_col=find(abs(grp_mid_x-cx)<dx*0.45 & min(abs(grp_mid_x-cx))==abs(grp_mid_x-cx) & abs(grp_mid_y-cy)<dy*0.45 & min(abs(grp_mid_y-cy))==abs(grp_mid_y-cy));

                if ~isempty(idx_col)
                    current_color=grp_colors(idx_col,:);
                    current_idx=idx_col;
                    ok=1;
                end

                if ~isempty(idx_rep)
                    w_colors(idx_rep,:)= current_color;
                    ok=1;
                end
            end
        end
        Screen('FillRect',window,[0 0 0])
    end

    grp=ones(length(w_colors(:,1)),1);
    for c=1:length(grp_colors)
        grp(all(w_colors==grp_colors(c,:),2))=c;
    end

    Answers.grp(strcmp(Answers.target,data_shuffled(trg)))=grp;
    status.test=status.test+1;
    OtherFct.Save_data;
end

status.suffix='';
OtherFct.Save_data
HideCursor
Screen('TextSize', window, FontSizeTrial);




