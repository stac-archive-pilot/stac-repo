%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com

% Required Psychtoolbox-3.

% References:
%Ovando-Tellez et al Communication Biology 2023
%Ovando-Tellez, Vigreux et al., Imaging Neurosciences 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


load('working_data');
%Load parameters of the task
OtherFct.GetParameters;


OtherFct.POLYF_Init
DisplayFct.Display_Instructions_Images(window,pathInstru); 


save('POLYF_ctx')

if ~exist('Answers', 'var')
    Answers={};
end

nb_trials_to_complete=nb_items_training+nb_items_test;

for trial_polyf=(status.test+status.training)-1 : nb_trials_to_complete

    if (trial_polyf==1) && (nb_items_training>0)
        DisplayFct.Display_Instructions_Images(window,strcat(InstructionScreens_Training,"1"));
        polyf_is_test=0;

    elseif trial_polyf > nb_items_training
        polyf_is_test=1;
    end

    if exist("POLYF", 'var')
        clear POLYF
        clear POLYF_resp
    end
    save('POLYF_ctx')

    OtherFct.POLYF_Init_trial

    OtherFct.Ask

    OtherFct.POLYF_End_trial
    clearvars -except POLYF
    
    load('POLYF_ctx.mat')
    
    if isfield(Answers, 'POLYF')
         POLYF=[Answers.POLYF; POLYF];
    end
    Answers.POLYF=POLYF;

    if trial_polyf <= nb_items_training
        status.training=status.training+1;
    else
        status.test=status.test+1;
    end

    OtherFct.Save_data

    if trial_polyf== nb_items_training + 1
        DisplayFct.Display_Instructions_Images(window,strcat(InstructionScreens_Training,"2"));
    end

end

delete('POLYF_ctx.mat')
RestrictKeysForKbCheck([]);
status.suffix='';
OtherFct.Save_data
Screen('TextSize', window, FontSizeTrial);
clearvars;
