%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com 
% Require Psychtoolbox-3.
% Created on Matlab2022b.    
% References:
%Ovando-Tellez et al Communication Biology 2023
%Ovando-Tellez, Vigreux et al., Imaging Neurosciences 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
RestrictKeysForKbCheck([]);   

 
clear 
mode="DEV"  %"DEV", "TESTING" "TESTING_PO"

Language="EN" % "FR", "EN"


if exist('temp_infos.mat','file')
    load("temp_infos.mat")
    PN=temp_infos.PN;
    Initials=temp_infos.Initials;
end


rng('shuffle')
%Load parameters of the task
Parameters.Main_Parameters;
PushedCom=0;
if Language=="FR"
    gui=get(gui_FR);

    uiwait(gui.Parent)

    while PushedCom==0 || length(PN)~=3
        gui=get(gui_FR);
        uiwait(gui.Parent)
    end
else
    gui=get(gui_EN);

    uiwait(gui.Parent)

    while PushedCom==0 || length(PN)~=3
        gui=get(gui_EN);
        uiwait(gui.Parent)
    end
end


temp_infos=struct('PN',PN, 'Initials', Initials);
save('temp_infos',"temp_infos"); 

%Create a folder with the data and the participants number
NameFolder=['Results/' DateString, '_' ,PN ,'_' ,Initials];
if ~exist(NameFolder,'dir')
    mkdir(NameFolder); 
end

save('working_data');
if ~exist('Passa_Infos', 'var')
    OtherFct.Order_Tasks;
    load("working_data.mat")
end

DisplayFct.ScreenStart;
HideCursor(OutputScreen);


ListenChar(2);
DisplayFct.Display_Instructions_Images(window,strcat(InstructionScreens_Main(1), "/"));

for index_task=1:length(Passa_Infos.Task_Order)
    task=char(Passa_Infos.Task_Order(index_task));
    save("working_data.mat");
    if ~exist([NameFolder '/' DateString '_' PNType task '_'  PN '_' Initials '.mat'],'file')
        DisplayFct.Display_Instructions_Images(window,strcat(InstructionScreens_Main(5) ,string(index_task)));

        Task=strcat("MainTaskFct.",task,"_", Language,"_Main");
        if ~ exist(strcat("+MainTaskFct/",task,"_", Language,"_Main.m"),"file")
            Task=strcat("MainTaskFct.",task,"_Main");
        end
        
        eval(Task);
        load('working_data.mat');
        DisplayFct.Display_Instructions_Images(window,InstructionScreens_Main(4));
    end
end

DisplayFct.Display_Instructions_Images(window,InstructionScreens_Main(3));
ListenChar(0);
delete("working_data.mat");
delete("temp_infos.mat");
WaitSecs(0.5);

sca;
clearvars
