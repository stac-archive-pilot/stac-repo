
% Author : Lucie Vigreux (lucievigreux@gmail.com) - ICM FrontLab

clear

study_path='ResFiles/'


task_name='POLYF'
idgrp_column='idgrp'

switch_column='idswi'
sim_column='W2V_IRS' %to replace if you have any

OtherFct.POLYF_corr_timing(study_path,task_name,"SWITCH")
OtherFct.POLYF_Metrics(study_path,task_name,"SWITCH",switch_column,idgrp_column, sim_column)