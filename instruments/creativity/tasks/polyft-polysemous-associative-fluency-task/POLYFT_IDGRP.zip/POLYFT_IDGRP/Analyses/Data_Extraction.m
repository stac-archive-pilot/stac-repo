% Author : Lucie Vigreux (lucievigreux@gmail.com) - ICM FrontLab

OtherFct.Build_Excel('IDGRP', '../Results/', 'ResFiles/')
OtherFct.Build_Excel('POLYF', '../Results/', 'ResFiles/')

OtherFct.POLYF_IDSWI;