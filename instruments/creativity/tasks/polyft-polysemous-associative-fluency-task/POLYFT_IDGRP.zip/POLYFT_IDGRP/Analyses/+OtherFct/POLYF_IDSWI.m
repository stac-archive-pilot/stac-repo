% Author : Lucie Vigreux (lucievigreux@gmail.com) - ICM FrontLab

tbl_rep=readtable('ResFiles/POLYF.xlsx','Sheet','POLYF');
tbl_swi=readtable('ResFiles/IDGRP.xlsx');
tbl_swi.n_part=str2double(tbl_swi.n_part);
tbl_rep.n_part=str2double(tbl_rep.n_part);
targets=unique(tbl_swi.target);
pts=unique(tbl_swi.n_part);

tbl_rep.idswi=NaN(height(tbl_rep),1);
tbl_rep.idgrp=NaN(height(tbl_rep),1);
tbl_rep.t_validated=round(tbl_rep.t_validated, 5);
tbl_swi.t_validated=round(tbl_swi.t_validated, 5);


for p=1:length(pts)
    for t=1:length(targets)
        idx_grp=find(tbl_swi.n_part==pts(p) & strcmp(tbl_swi.target,targets(t)));
        idx_rep_=find(tbl_rep.n_part==pts(p) & strcmp(tbl_rep.target,targets(t)) & ~strcmp(tbl_rep.response,'') & tbl_rep.is_resp==1 & tbl_rep.suppressed==0);
        resps=tbl_swi.response(idx_grp);
            for r=1:length(resps)
                idx_rep=find(tbl_swi.t_validated(idx_grp(r))==tbl_rep.t_validated(idx_rep_));
                if ~isempty(idx_rep)
                        tbl_rep.idgrp(idx_rep_(idx_rep))=tbl_swi.grp(idx_grp(r));
                end
            end

            if ~isempty(find(idx_rep_, 1))
                tbl_rep.idswi(idx_rep_)=[NaN; diff(tbl_rep.idgrp(idx_rep_))~=0];
            end
    end
end

tbl_rep.idswi(isnan(tbl_rep.idgrp))=NaN;
tbl_rep=tbl_rep(tbl_rep.is_test==1 & tbl_rep.is_resp==1,:);

writetable(tbl_rep,'ResFiles/POLYF.xlsx','Sheet','SWITCH','WriteMode','overwritesheet');
disp('Placement of switchings done');