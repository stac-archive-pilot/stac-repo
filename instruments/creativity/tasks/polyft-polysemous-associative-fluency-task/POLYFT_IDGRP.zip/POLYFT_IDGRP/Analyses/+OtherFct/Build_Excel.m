% Author : Lucie Vigreux (lucievigreux@gmail.com) - ICM FrontLab

function Build_Excel(task, data_path, save_path)
list_part=dir(data_path);
list_part={list_part.name};
list_part=list_part(3:end);


var=['Out.Output.' task];

if contains(task,'POLYF')
    var=['Out.Output.POLYF.POLYF' ];
end

for i=1:length(list_part)
    dir_part=list_part{i};
    task_part=dir([data_path dir_part '/']);
    task_part={task_part.name};
    p_number= strsplit(dir_part,'_');
    p_number=p_number{2};

    if any(contains(task_part,['_' task '_']))
        file_task=task_part{contains(task_part,['_' task '_'])};
        Out=load([data_path dir_part '/' file_task]);

        tbl=eval(var);

        if istable(tbl)
            tbl.n_part=repmat(p_number, height(tbl),1);
        else
            [tbl(:).n_part]=deal(p_number);

        end

        
        if exist("data_table","var")
            data_table=[data_table; tbl];
        else
            data_table=tbl;
        end
    end
end

if exist("data_table","var")
    if ~istable(data_table)
        tbl=struct2table(data_table);
    else
        tbl=data_table;
    end
    tbl = [tbl(:,end) tbl(:,1:end-1)];
    writetable(tbl,[save_path task '.xlsx'], 'Sheet',task);

end


end

