
% Author : Lucie Vigreux (lucievigreux@gmail.com) - ICM FrontLab
function POLYF_corr_timing(study_path,task_name,swi_sheet)

tbl_rep=readtable([study_path task_name '.xlsx'],'Sheet',swi_sheet);
tbl_rep = sortrows(tbl_rep,"t_validated","ascend");
tbl_rep = sortrows(tbl_rep,"target","ascend");
tbl_rep = sortrows(tbl_rep,"n_part","ascend");


rep_=tbl_rep;
tbl_rep=tbl_rep(tbl_rep.is_test==1,:);
idxs=tbl_rep.is_resp==1;
tbl_rep=tbl_rep(idxs,:);


corr_t_inter=0;
if  ~any(strcmpi(tbl_rep.Properties.VariableNames,"raw_t_inter"))
    tbl_rep.raw_t_inter=tbl_rep.t_inter;
    tbl_rep.raw_duration_writing=tbl_rep.duration_writing;
    tbl_rep.raw_start2write=tbl_rep.start2write;
    tbl_rep.raw_typing_speed=tbl_rep.typing_speed;
    tbl_rep.raw_tinter_diff=[NaN; tbl_rep.start2write(2:end)-tbl_rep.t_validated(1:end-1)];
    tbl_rep.raw_tinter_diff(tbl_rep.raw_t_inter==0)= tbl_rep.start2write(tbl_rep.raw_t_inter==0);
    corr_t_inter=1;

    tbl_rep.modified_it=repmat("No", height(tbl_rep),1);

    id0s=zeros(height(tbl_rep),1);

end

n_part=unique(tbl_rep.n_part);
n=length(n_part);

list_target=unique(tbl_rep.target);
n_targ=length(list_target);



if corr_t_inter

    for p=1:n
        idx_pt=strcmpi(tbl_rep.n_part,n_part(p));
        if idx_pt==0
            idx_pt=tbl_rep.n_part==n_part(p);
        end
        for t=1:n_targ
            id0=find(idx_pt & strcmpi(tbl_rep.target ,list_target{t}),1);
            if ~isempty(id0)
                id0s(id0)=1;
                tbl_rep.t_inter(id0)=tbl_rep.t_inter(id0)+tbl_rep.start2write(id0);
                tbl_rep.modified_it(id0,:)="start";
            end
        end
    end


    for p=1:n
       
        idx_pt_=strcmpi(tbl_rep.n_part,n_part(p));
        if idx_pt_==0
            idx_pt_=tbl_rep.n_part==n_part(p);
        end
        idx_pt_=idx_pt_ & tbl_rep.is_resp;
        idx_pt=idx_pt_ & ~id0s ;


        pt_resp=tbl_rep.response(idx_pt_ );
        
        typing_speed=tbl_rep.raw_typing_speed(idx_pt_);
        id_min=find(typing_speed==min(typing_speed));

        while strlength(pt_resp(id_min))<3
            typing_speed=typing_speed(typing_speed>min(typing_speed));
            id_min=find(typing_speed==min(typing_speed));
        end
        wr_smin_pt=min(typing_speed);

        th_wr=wr_smin_pt.*(tbl_rep.total_nb_keys_pressed(idx_pt_ )-1);


        idx_pt=idx_pt_ ;
        tbl_rep.duration_writing(idx_pt)=th_wr;
    
        tbl_rep.start2write(idx_pt & id0s)= tbl_rep.t_validated(idx_pt & id0s) - tbl_rep.duration_writing(idx_pt & id0s) ;
        tbl_rep.t_inter(idx_pt & id0s)=tbl_rep.start2write(idx_pt & id0s);

        tbl_rep.start2write(idx_pt & ~id0s)= tbl_rep.t_validated(idx_pt & ~id0s) - tbl_rep.duration_writing(idx_pt & ~id0s);
        tbl_rep.t_inter(idx_pt & ~id0s)=tbl_rep.start2write(idx_pt & ~id0s) - tbl_rep.t_validated(find(idx_pt & ~id0s)-1);
        tbl_rep.modified_it(idx_pt & ~id0s)="Yes";

    end
    pb=tbl_rep.t_inter < tbl_rep.raw_t_inter;
    if ~isempty(find(pb & ~id0s, 1))
        tbl_rep.modified_it(pb & ~id0s)="pb";
        tbl_rep.t_inter(pb & ~id0s)=tbl_rep.raw_t_inter(pb & ~id0s);
    end

    

tbl_rep.typing_speed=tbl_rep.duration_writing./(tbl_rep.total_nb_keys_pressed-1);

end

tbl_rep.is_resp(tbl_rep.t_inter<0.005)=0;

writetable(rep_,[study_path task_name '.xlsx'],'Sheet','REP_raw','WriteMode','overwritesheet');
writetable(tbl_rep,[study_path task_name '.xlsx'],'Sheet','SWITCH','WriteMode','overwritesheet');
disp('Correction of timing done');
end