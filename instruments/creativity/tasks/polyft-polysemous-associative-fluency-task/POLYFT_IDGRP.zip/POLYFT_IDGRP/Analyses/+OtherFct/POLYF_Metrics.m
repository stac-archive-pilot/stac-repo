
% Author : Lucie Vigreux (lucievigreux@gmail.com) - ICM FrontLab


function POLYF_Metrics(study_path,task_name,swi_sheet,switch_column,grp_column,sim_column)

tbl_rep=readtable([study_path task_name '.xlsx'],'Sheet',swi_sheet);
tbl_rep=renamevars(tbl_rep,switch_column,'SWITCHING');
tbl_rep=renamevars(tbl_rep,grp_column,'CLUSTER');


idxs=tbl_rep.is_resp==1;
tbl_rep=tbl_rep(idxs,:);


metrics=["fluency_all" "fluency_unique" "duplicates" "biggest_clus" "mean_clus_size" "first_switch" "nb_swi" "nb_clus" "nb_meanings" "IRT_targ" "IRT_clus" "IRT_swi"];



if any(strcmp(sim_column,tbl_rep.Properties.VariableNames))
    tbl_rep=renamevars(tbl_rep,sim_column,'SIM');
    metrics=[metrics  "IRS_targ" "IRS_clus" "IRS_swi"];
end

list_target=unique(tbl_rep.target);
if isempty(list_target{1})
    list_target=list_target(2:end);
end
tbl_target=table(list_target);
n_targ=length(list_target);
nb_metrics=length(metrics);
m_metrics=zeros(height(tbl_target),nb_metrics);


n_part=unique(tbl_rep.n_part);
n_pt=length(n_part);


tbl_metrics=table();
tbl_metrics.n_part=repmat(n_part,n_targ,1);
tbl_metrics= sortrows(tbl_metrics,"n_part","ascend");
tbl_metrics.target=repmat(list_target,n_pt,1);
tbl_metrics= sortrows(tbl_metrics,"target","ascend");
tbl_metrics = sortrows(tbl_metrics,"n_part","ascend");



for m=1:nb_metrics
    eval(['tbl_metrics.' char(metrics(m)) '=NaN(size(tbl_metrics.n_part));']);
end


for t=1:n_targ
    list_target{t}

    for m=1:nb_metrics
        eval([char(metrics(m)) '=NaN(length(n_part),1);']);
    end

    for p=1:n_pt
        idx_pt=strcmpi(tbl_rep.n_part,n_part(p));
        if idx_pt==0
            idx_pt=tbl_rep.n_part==n_part(p);
        end
        idx_targ=idx_pt & strcmpi(tbl_rep.target ,list_target(t));

        if ~isempty(find(idx_targ,1))

            resp=tbl_rep.corrected_response(idx_targ,:);
            [~, idx_uniques,~ ]=unique(resp(~strcmpi(resp,list_target(t))));

            fluency_unique(p)=length(idx_uniques);
            fluency_all(p)=length(resp);
            duplicates(p)=fluency_all(p)-fluency_unique(p);
            nb_swi(p)=sum(idx_targ & tbl_rep.SWITCHING==1,'omitnan');
            nb_clus(p)=sum(idx_targ & tbl_rep.SWITCHING==0,'omitnan');

            idx_rep=find(idx_targ & tbl_rep.SWITCHING==1,1);
            if ~isempty(idx_rep)


                comps=tbl_rep.SWITCHING(idx_targ,:);
                if length(comps)>1
                    clus_sz=[1;find(comps==1); length(comps)+1];

                    big=max(diff(clus_sz));
                    if ~isempty(big)
                        biggest_clus(p)=big;
                        mean_clus_size(p)=mean(diff(clus_sz),'omitnan');
                    end


                else
                    biggest_clus(p)=length(comps);
                    mean_clus_size(p)=length(comps);
                end


            else
                biggest_clus(p)=length(find(idx_targ));
                mean_clus_size(p)=length(find(idx_targ));

            end

            if ~isempty(find(tbl_rep.SWITCHING(idx_targ,:)==1,1))
                first_switch(p)=find(tbl_rep.SWITCHING(idx_targ,:)==1,1);
            end

            IRT_targ(p)=mean(tbl_rep.t_inter(idx_targ),'omitnan');

            IRT_clus(p)= mean(tbl_rep.t_inter(idx_targ & tbl_rep.SWITCHING==0 ),'omitnan');
            IRT_swi(p)= mean(tbl_rep.t_inter(idx_targ & tbl_rep.SWITCHING==1 ),'omitnan');


            if any(strcmp('SIM',tbl_rep.Properties.VariableNames))
                IRS_targ(p)=mean(tbl_rep.SIM(idx_targ),'omitnan');

                IRS_clus(p)= mean(tbl_rep.SIM(idx_targ & tbl_rep.SWITCHING==0 ),'omitnan');
                IRS_swi(p)= mean(tbl_rep.SIM(idx_targ & tbl_rep.SWITCHING==1 ),'omitnan');

            end

            clusters=unique(tbl_rep.CLUSTER(idx_targ,:));
            nb_meanings(p)=length(clusters);


            if any(strcmp('SIM',tbl_rep.Properties.VariableNames))
                idx_targ_=find(idx_targ);

                if ~isempty(find(idx_targ_, 1))
                    min_IRS(p)= min(tbl_rep.SIM(idx_targ,:));
                    mean_IRS(p)=mean(tbl_rep.SIM(idx_targ,:), 'omitnan');
                    total_IRS(p)= sum(tbl_rep.SIM(idx_targ,:),'omitnan');

                    total_IRD(p)= length(find(idx_targ_)) - sum(tbl_rep.SIM(idx_targ,:),'omitnan');
                end

            end

        end
    end
    for m=1:nb_metrics
        eval(['tbl_metrics.' char(metrics(m)) '(strcmp(tbl_metrics.target,list_target{t}) )=' char(metrics(m)) ';'])
    end

end

%
tbl_metrics=tbl_metrics(~isnan(tbl_metrics.fluency_all),:);

writetable(tbl_metrics,[study_path task_name '.xlsx'],'Sheet','METRICS','WriteMode','overwritesheet');
disp('Metrics computed');
end
