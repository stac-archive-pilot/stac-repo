
% Author: Lucie Vigreux based on Gino Battistello's code
% Contact: lucievigreux@gmail.com 
%
%Note: Need to have Psychtoolbox-3 installed.

function [time_start,time_end,key_pressed]=Display_Instructions_Images(scr,Instru_root)


RestrictKeysForKbCheck([32]);
time_start=datetime("now");

rect=Screen('Rect',scr);
 list_ins=dir(strcat(Instru_root, "*.png"));
if length(list_ins)>1
    for id=1:length(list_ins)
        im{id}=imread(strcat(Instru_root, list_ins(id).name));
    end
else
    if exist(strcat(Instru_root, list_ins.name),'file')
        im{1}=imread(strcat(Instru_root, list_ins.name));
    else
        im{1}=imread(strcat(Instru_root, list_ins.name(2:end)));
    end

end 

for p=1:length(list_ins)
    
    Screen('PutImage', scr, im{p}, rect);
    Screen(scr,'Flip');

    WaitSecs(.5);
    KbWait;

end

time_end=datetime("now");
