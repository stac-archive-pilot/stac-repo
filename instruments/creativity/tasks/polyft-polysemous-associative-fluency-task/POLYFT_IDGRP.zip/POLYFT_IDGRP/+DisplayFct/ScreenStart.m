%%%%%%%%Screen start

%Call some default settings for setting up Psychtoolbox for Macintosh.
% %Can comment out if on Windows.
Screen('Preference', 'SkipSyncTests', 2);

% Get the screen numbers. This gives us a number for each of the screens
% attached to the computer.
screens = Screen('Screens');

% Draw on the output screen selected in the parameters
screenNumber = OutputScreen;

% Define black.
black = BlackIndex(screenNumber);

% Open a screen window
[window, windowRect] = PsychImaging('OpenWindow',screenNumber, black);

% Get the size of the on screen window
[screenXpixels, screenYpixels] = Screen('WindowSize', window);

% Query the frame duration
%ifi = Screen('GetFlipInterval', window);

% Get the center coordinate of the window
[xCenter, yCenter] = RectCenter(windowRect);
%Get the dimension on the screen
rect= [ 0 0 screenXpixels screenYpixels]; 

%Define the position where the words will be presented.
LeftScreenPosition=rect(3)*0.4;
RightScreenPosition=rect(3)*0.6;
TopScreenPosition=rect(4)*0.35;
BottomScreenPosition=rect(4)*0.6;


