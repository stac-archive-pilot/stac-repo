%%%%%%%%%%%%%%%%
% Author: Lucie Vigreux based on  Matthieu Bernard's work
% Contact: lucievigreux@gmail.com
%
%Note: Need to have Psychtoolbox-3 installed.
%%%%%%%%%%%%%%%%

function DisplayWords(ListElements,Question,Background,window,LeftScreenPosition,RightScreenPosition,BottomScreenPosition,TopScreenPosition,FontSizeTrial,ColorWord)
%%
%Check how many elements need to be drawn on the screen
HowManyElements=length(ListElements);

% Setup the font size for the text
Screen('TextFont', window, 'Ariel');
Screen('TextSize', window, FontSizeTrial);

%If only one element and is a character
if ischar(ListElements)
  
    %Draw the word on the middle of the screen.
    DrawFormattedText(window, ListElements, 'center', 'center',ColorWord);

%If only one element by is a string    
elseif HowManyElements == 1
    
    %Transform the string into character format
    textString = char(ListElements{1});
    
    %Draw the word on the middle of the screen.
    DrawFormattedText(window, textString, 'center', 'center',ColorWord);
    
%If two elements    
elseif HowManyElements == 2
    
    %Transform the two strings into character format
    textString_Left = char(ListElements{1});
    textString_Right = char(ListElements{2});
    
    %Define the textBounds for the left item in order to change its
    %position accordingly.
    [~, ~, textBounds]=DrawFormattedText(window, textString_Left, LeftScreenPosition, 'center',ColorWord);
    DisplaceText=textBounds(3)-textBounds(1);
    
    %Fill the screen in black to remove the previous text
    Screen('FillRect', window, Background);
    
    %Draw the first text in the middle left part of the screen using the textBounds
    DrawFormattedText(window, textString_Left, LeftScreenPosition-DisplaceText, 'center',ColorWord);
    %Draw the second text in the middle right part of the screen.
    DrawFormattedText(window, textString_Right, RightScreenPosition, 'center',ColorWord);
   
%If three elements    
elseif HowManyElements == 3
    
    %Transform the three strings into character format
    textString_Top = char(ListElements{1});
    textString_Left = char(ListElements{2});
    textString_Right = char(ListElements{3});
    
    %Define the textBounds for the left item in order to change its
    %position accordingly.
    [~, ~, textBounds]=DrawFormattedText(window, textString_Left, LeftScreenPosition, BottomScreenPosition,Background);
    DisplaceText=textBounds(3)-textBounds(1);
    
    %Fill the screen in black to remove the previous text
   % Screen('FillRect', window, Background);
    
    %Draw the first text in the middle top part of the screen
    DrawFormattedText(window, textString_Top, 'center', TopScreenPosition,ColorWord);
    %Draw the first text in the bottom left part of the screen using the textBounds
    DrawFormattedText(window, textString_Left, LeftScreenPosition-DisplaceText, BottomScreenPosition,ColorWord);
    %Draw the second text in the bottom right part of the screen.
    DrawFormattedText(window, textString_Right, RightScreenPosition, BottomScreenPosition,ColorWord);
    
    %If necessary draw a question mark on the center of the screen
    if Question==1
        DrawFormattedText(window, '?', 'center','center',ColorWord); %Question mark
    end
    
end

%Draw the text(s) on the screen
Screen('Flip', window,0,1);

end