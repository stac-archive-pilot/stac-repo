% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com 

classdef gui_FR < matlab.ui.componentcontainer.ComponentContainer

    % Properties that correspond to app components
    properties (Access = private, Transient, NonCopyable)
        Fig                           matlab.ui.Figure
        NumroEditField                matlab.ui.control.EditField
        NumroEditFieldLabel           matlab.ui.control.Label
        InitialesEditField            matlab.ui.control.EditField
        InitialesEditFieldLabel       matlab.ui.control.Label
        InformationsparticipantLabel  matlab.ui.control.Label
        COMMENCERButton               matlab.ui.control.Button
        CREXLabel                     matlab.ui.control.Label
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: COMMENCERButton
        function COMMENCERButtonPushed(comp, event)
            assignin('base','Initials',comp.InitialesEditField.Value)
            assignin('base','PN',comp.NumroEditField.Value)
            assignin('base','PushedCom',1)
            closereq();
        end
    end

    methods (Access = protected)
        
        % update components, triggered after drawnow
        function update(comp)
            
        end

        % The setup method executes once when user constructs the object
        function setup(comp)


            comp.Parent.Name='GUI_FR';
            comp.Parent.Position=[100 100 200 200];
            comp.Position=[1 1 200 200];
            comp.BackgroundColor = [0.94 0.94 0.94];


            % Create CREXLabel
            comp.CREXLabel = uilabel(comp);
            comp.CREXLabel.HorizontalAlignment = 'center';
            comp.CREXLabel.FontSize = 14;
            comp.CREXLabel.FontWeight = 'bold';
            comp.CREXLabel.FontColor = [0.502 0.502 0.502];
            comp.CREXLabel.Position = [3 166 182 26];
            comp.CREXLabel.Text = 'PolyFT FR';

            % Create COMMENCERButton
            comp.COMMENCERButton = uibutton(comp, 'push');
            comp.COMMENCERButton.ButtonPushedFcn = matlab.apps.createCallbackFcn(comp, @COMMENCERButtonPushed, true);
            comp.COMMENCERButton.FontWeight = 'bold';
            comp.COMMENCERButton.FontColor = [0.502 0.502 0.502];
            comp.COMMENCERButton.Position = [54 26 95 30];
            comp.COMMENCERButton.Text = 'COMMENCER';

            % Create InformationsparticipantLabel
            comp.InformationsparticipantLabel = uilabel(comp);
            comp.InformationsparticipantLabel.HorizontalAlignment = 'center';
            comp.InformationsparticipantLabel.FontWeight = 'bold';
            comp.InformationsparticipantLabel.Position = [24 131 143 22];
            comp.InformationsparticipantLabel.Text = 'Informations participant';

            % Create InitialesEditFieldLabel
            comp.InitialesEditFieldLabel = uilabel(comp);
            comp.InitialesEditFieldLabel.Position = [51 102 46 22];
            comp.InitialesEditFieldLabel.Text = 'Initiales';


            % Create InitialesEditField
            comp.InitialesEditField = uieditfield(comp, 'text');
            comp.InitialesEditField.Position = [112 102 30 17]; 
            comp.InitialesEditField.Value = evalin('base','Initials');


            % Create NumroEditFieldLabel
            comp.NumroEditFieldLabel = uilabel(comp);
            comp.NumroEditFieldLabel.Position = [49 73 47 22];
            comp.NumroEditFieldLabel.Text = 'Numéro';

            % Create NumroEditField
            comp.NumroEditField = uieditfield(comp, 'text');
            comp.NumroEditField.HorizontalAlignment = 'left';
            comp.NumroEditField.Position = [112 76 30 19];           
            comp.NumroEditField.Value = evalin('base','PN');
        end
    end
end