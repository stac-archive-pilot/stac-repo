function Created=CreationFolderSaveData(Path,Save,NameFolder)

%%%%%%%%%%%%%%%%
% Version: 1
% Last Edited: 23/10/2018
% Author: Matthieu Bernard
% Contact: matthieubernard@outlook.com
%
%INPUT: - Path: The path where the new folder should be created
%       - Save: If decided to save the data.
%       - NameFolder: The name of the new created folder
%
% OUTPUT: - Created: Variable with the path of the newly created folder.
%%%%%%%%%%%%%%%%

%If decided to save the data and the folder doesn't already exist
if Save==1 && ~(exist(NameFolder,'dir')==7)
    %Create the folder in the correct path.
    pathSave=strcat(Path,NameFolder);
    mkdir(pathSave)
end

%Store in variable the path for the current folder
Created=pathSave;

end