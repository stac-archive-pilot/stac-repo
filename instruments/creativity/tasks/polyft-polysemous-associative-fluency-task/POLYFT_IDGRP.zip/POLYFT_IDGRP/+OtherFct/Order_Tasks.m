% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com 
%

% Required Psychtoolbox-3.
% Created on Matlab2022b.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if  exist([ NameFolder '/' DateString '_' PNType  'Passa_Infos_' PN   '_' Initials '.mat'],'file')
    load([ NameFolder '/' DateString '_' PNType  'Passa_Infos_' PN   '_' Initials '.mat']);
else
    randomok=0;
    while randomok==0
        randomok=1;
        stim_list=unique(Passa_Params.stim_list);
        stim_list=stim_list( ~cellfun(@isempty,stim_list));

        if ~isempty(stim_list)
            idx_=[];

            for s=1:length(stim_list)
                list=stim_list{s};
                if  ~isempty(list)
                    idx_to_fill=find(strcmpi(Passa_Params.stim_list,list));
                    idx_=[idx_ ; idx_to_fill];
                    l=length(idx_to_fill);
                    if l>1
                        ints=randperm(l,l);
                        for i=1:l
                            Passa_Params.stim_list(idx_to_fill(i))={char(strcat(string(Passa_Params.stim_list{idx_to_fill(i)}), "_", string(ints(i))))};
                        end
                    end
                end
            end

            idx_=~cellfun(@isempty,Passa_Params.stim_list);

            STIM_List=[Passa_Params.Tache(idx_), Passa_Params.stim_list(idx_)];


        end


        blocks_Order=cell(length(find(~isnan(Passa_Params.P1))),1);

        to_place=Passa_Params.Tache(find(Passa_Params.P1==0));
        pairs=unique(Passa_Params.P1);
        pairs=pairs(~isnan(pairs));

        for p=1:length(pairs)
            rk=pairs(p);
            if rk>0
                if ~ismember(rk, Passa_Params.P2)
                    duo=Passa_Params.Tache(Passa_Params.P1==rk);
                    if length(duo)==2
                        duo=duo(randperm(2,2));
                        blocks_Order(rk)=duo(1,:);
                        blocks_Order(Passa_Params.P2(Passa_Params.P1==rk))=duo(2,:);
                    end
                else
                    blocks_Order(rk)=Passa_Params.Tache(Passa_Params.P1==rk);
                end
            end

        end

        ftarg=randi(100)>=50;
        ord_STIM_List={};
        freq_is_targ={};
        idx_to_fill=cellfun(@isempty,blocks_Order);
        blocks_Order(idx_to_fill)=to_place(randperm(length(to_place),length(to_place)));
        Passa_Infos=struct2table(struct('Task_Order',blocks_Order, 'STIM_List', NaN));

        for i=1:height(Passa_Infos)
            idx=find(strcmp(Passa_Infos.Task_Order(i), STIM_List(:,1)));
            if ~isempty(idx)
                ord_STIM_List(i)=STIM_List(idx,2);
            else
                ord_STIM_List(i)={''};
            end

            if contains(Passa_Infos.Task_Order(i),'CPTX')
                freq_is_targ(i)={ftarg==1};
            else
                freq_is_targ(i)={''};
            end
        end
        Passa_Infos.STIM_List=ord_STIM_List';
        Passa_Infos.freq_is_targ=freq_is_targ';

        
    end
    save([ NameFolder '/' DateString '_' PNType  'Passa_Infos_' PN   '_' Initials '.mat'],"Passa_Infos");
    clearvars -except Passa_Infos
    
end
