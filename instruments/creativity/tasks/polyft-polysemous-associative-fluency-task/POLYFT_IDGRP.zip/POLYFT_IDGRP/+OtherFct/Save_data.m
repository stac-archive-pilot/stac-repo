%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com 

% Required Psychtoolbox-3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(status.suffix)
    delete([NameFolder '/' DateString '_' PNType task '_'  PN '_' Initials '_unfinished.mat'])
    Output=struct('status',status,'Seed',Seed_is,task,{Answers});
    %Save the responses in the newly created folder
    save([NameFolder '/' DateString '_' PNType task '_'  PN '_' Initials],'Output');
else
    Output=struct('status',status,'Seed',Seed_is,task,{Answers}, 'data_shuffled',{data_shuffled});
    %Save the responses in the newly created folder
    save([NameFolder '/' DateString '_' PNType task '_'  PN '_' Initials status.suffix],'Output');
end

if (contains(task,'POLYF') || contains(task,'INTERF')) && isempty(status.suffix)
    if exist("POLYF_resp.mat","file")
        load ("POLYF_resp.mat");
        POLYF_resp=[POLYF_resp ;POLYF(POLYF.is_resp & POLYF.is_test & ~POLYF.suppressed,["target","response", "t_validated"])];
    else
        POLYF_resp=POLYF(POLYF.is_resp & POLYF.is_test & ~POLYF.suppressed,["target","response", "t_validated"]);
    end
    save('POLYF_resp.mat',"POLYF_resp");
end

