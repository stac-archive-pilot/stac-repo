%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com

% Required Psychtoolbox-3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



while GetSecs<limitTime_polyf_
    resp = 0;
    drawnow;

    while GetSecs<limitTime_polyf_ && ~any(resp==enabled_keys)

        if GetSecs - secs > 0.05
            secs=GetSecs;
            drawnow
        end
        if osx==0
            event = PsychHID('KbQueueGetEvent', [], 0.0001);
            if ~isempty(event) && event.Pressed && (event.CookedKey > 0)
                resp = event.CookedKey;
                secs=event.Time;
            else
                resp = -1;
            end

        else

            resp = OSX_JAVA_GETCHAR.getChar;
            if resp == -1
                OSX_JAVA_GETCHAR.setRedispatchFlag(0);
                error('GetChar buffer overflow. Use "FlushEvents" to clear error');
            end
            rawEventTimeMs = OSX_JAVA_GETCHAR.getEventTime;
            secs = JavaTimeToGetSecs(rawEventTimeMs, -1);
        end

        if ~any(resp==enabled_keys)
            drawnow;
            if exist('fflush')
                builtin('fflush', 1);
            end
        end

    end

    if resp==8
        if consec_del==0
            temp_word=polyf_resp{idx_rep_polyf};
        elseif length(temp_word)==consec_del+1
            resp=key_enter{1};
            polyf_suppressed(idx_rep_polyf)={1};
            polyf_resp{idx_rep_polyf}=temp_word;
        end
    end

    switch resp
        case key_delete

            if ~isempty(polyf_resp{idx_rep_polyf})
                consec_del=consec_del+1;

                if isempty(keyspressed{idx_rep_polyf})
                    keyspressed{idx_rep_polyf}='_8';
                    keyspolyf{idx_rep_polyf}='1';
                    tstamps_keys{idx_rep_polyf}= char(string(secs-t0));
                else
                    keyspressed{idx_rep_polyf}=[keyspressed{idx_rep_polyf} '_8'];
                    keyspolyf{idx_rep_polyf}=[keyspolyf{idx_rep_polyf} '_1'];
                    tstamps_keys{idx_rep_polyf}=[tstamps_keys{idx_rep_polyf} '_'  char(string(secs-t0))];
                end

                polyf_resp{idx_rep_polyf}=polyf_resp{idx_rep_polyf}(1:end-1);
                Screen('FillRect',window,[0 0 0],resp_rect);
                DrawFormattedText2(polyf_resp{idx_rep_polyf} ,'win',window,'baseColor',NormalColor, 'winRect',resp_rect','sx','center','xalign','center','sy','center','yalign','center');
                Screen('Flip', window,0,1);
            end

        case key_enter
            if ~isempty(polyf_resp{idx_rep_polyf})

                polyf_t_validated(idx_rep_polyf)={secs-onset_polyf_};
                keyspressed{idx_rep_polyf}=[keyspressed{idx_rep_polyf} '_13'];
                keyspolyf{idx_rep_polyf}=[keyspolyf{idx_rep_polyf} '_1'];
                tstamps_keys{idx_rep_polyf}=[tstamps_keys{idx_rep_polyf} '_'  char(string(polyf_t_validated{idx_rep_polyf}))];

                idx_rep_polyf=idx_rep_polyf+1;

                polyf_suppressed(idx_rep_polyf)={0};
                polyf_resp{idx_rep_polyf}='';
                keyspressed{idx_rep_polyf}='';
                tstamps_keys{idx_rep_polyf}='';
                polyf_t_validated(idx_rep_polyf)={NaN};
                polyf_start2write(idx_rep_polyf)={NaN};
                keyspolyf(idx_rep_polyf)={NaN};
                polyf_t_inter(idx_rep_polyf)={NaN};
                consec_del=0;
                temp_word='';

                if polyf_suppressed{idx_rep_polyf-1}==0
                    deleted_resp(idx_rep_polyf)={0};
                else
                    deleted_resp{idx_rep_polyf}=deleted_resp{idx_rep_polyf-1}+1;
                end

                Screen('FillRect',window,[0 0 0],resp_rect);

                Screen('Flip', window,0,1);
            end

        case kb_keys
            consec_del=0;
            temp_word='';

            if isempty(polyf_resp{idx_rep_polyf})
                polyf_resp{idx_rep_polyf}= char(resp);
                polyf_start2write{idx_rep_polyf}=secs-onset_polyf_;

                if idx_rep_polyf>1
                    polyf_t_inter{idx_rep_polyf}=polyf_start2write{idx_rep_polyf}-polyf_t_validated{idx_rep_polyf-1};
                else
                    polyf_t_inter{idx_rep_polyf}=polyf_start2write{idx_rep_polyf};
                end
            else
                polyf_resp{idx_rep_polyf}=[polyf_resp{idx_rep_polyf} char(resp)];
            end

            if isempty(keyspressed{idx_rep_polyf})
                keyspolyf{idx_rep_polyf}='1';
                keyspressed{idx_rep_polyf}=char(resp);
                tstamps_keys{idx_rep_polyf}= char(string(secs-t0));
            else
                keyspolyf{idx_rep_polyf}=[keyspolyf{idx_rep_polyf} '_1'];
                keyspressed{idx_rep_polyf}=[keyspressed{idx_rep_polyf} char(resp)];
                tstamps_keys{idx_rep_polyf}=[tstamps_keys{idx_rep_polyf} '_'  char(string(secs-t0))];
            end


            Screen('FillRect',window,[0 0 0],resp_rect);
            DrawFormattedText2(polyf_resp{idx_rep_polyf} ,'win',window,'baseColor',NormalColor, 'winRect',resp_rect','sx','center','xalign','center','sy','center','yalign','center');
            Screen('Flip', window,0,1);
    end

end

