%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com

% Required Psychtoolbox-3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


otpt=['Output.' task];
 if isstruct(eval(otpt))
    vars=fields(eval(otpt));
    if  ~contains(task,["TMT","STROOP","POLYF_CPTX","POLYF_PREP"])
        for i=1:length(vars)
            assignin('base',vars{i},eval([ otpt '.' vars{i}]));
           
        end
    else
        for i=1:length(vars)
            if isstruct(eval([otpt '.' vars{i}])) && contains(task,["POLYF_CPTX","POLYF_PREP"])
                sub_vars=fields(eval([otpt '.' vars{i}]));
                for j=1:length(sub_vars)
                    assignin('base',sub_vars{j},eval(['{' otpt '.' vars{i} '.' sub_vars{j} '}'].'));
                end
            else
                assignin('base',vars{i},eval([ '{' otpt '.' vars{i} '}' ]).');
            end
        end
        
    end

else
    Answers=eval(otpt);
    data_shuffled=Output.data_shuffled;
    status=Output.status;
end
