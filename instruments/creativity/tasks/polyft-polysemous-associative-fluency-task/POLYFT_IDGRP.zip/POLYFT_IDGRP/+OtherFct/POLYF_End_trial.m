%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com

% Required Psychtoolbox-3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

is_resp=num2cell((~cellfun(@isnan,polyf_t_validated).*(cell2mat(polyf_t_validated)<Time2Wait)));

duration_writing=num2cell(cell2mat(polyf_t_validated)-cell2mat(polyf_start2write));
nb_keys=cell2mat(cellfun(@(x) length(x) ,keyspressed ,'UniformOutput',false)) - count(keyspressed, '_') - count(keyspressed,'13');

typing_speed=num2cell(cell2mat(duration_writing)./(nb_keys-1));

key_is_polyf=cellfun(@(x) str2double(strsplit(string(x), '_')),keyspolyf,'UniformOutput',false);
nb_keys_polyf=cellfun(@sum,key_is_polyf);
for i=1:length(key_is_polyf)
    l=tstamps_keys{i};
    if ~isempty(l)
        l=strsplit(l,'_');
        tstamp_keys_polyf{i}=str2double(l(key_is_polyf{i}==1));
    else
        tstamp_keys_polyf{i}=NaN;
    end
end

tinter_keys_polyf=cellfun(@(x) diff(x), tstamp_keys_polyf,'UniformOutput',false);

mean_tinter_key_polyf=cellfun(@(x) mean(x),tinter_keys_polyf,'UniformOutput',false);

max_tinter_key_polyf=cellfun(@(x) max(x),tinter_keys_polyf,'UniformOutput',false);
max_tinter_key_polyf(cellfun(@isempty, max_tinter_key_polyf))={NaN};

min_tinter_key_polyf=cellfun(@(x) min(x),tinter_keys_polyf,'UniformOutput',false);
min_tinter_key_polyf(cellfun(@isempty, min_tinter_key_polyf))={NaN};

tinter_keys_polyf(cellfun(@isempty, tinter_keys_polyf))={[0]};
tinter_keys_polyf=cellfun(@(x) char(strjoin(string(x),"_")), tinter_keys_polyf,'UniformOutput',false);


POLYF=struct('task',task,'target',target_word,'is_resp',is_resp, 'is_test' ,polyf_is_test,'suppressed', polyf_suppressed,  'response',polyf_resp,'start2write',polyf_start2write, 't_validated',polyf_t_validated,'t_inter', polyf_t_inter, 'duration_writing', duration_writing, 'nb_deleted_resp',deleted_resp, 'key_pressed', keyspressed, 't_stamps_keys', tstamps_keys, 'polyf_t_inter_keys', tinter_keys_polyf, 'polyf_mean_t_inter_keys', mean_tinter_key_polyf, 'polyf_min_t_inter_keys', min_tinter_key_polyf, 'polyf_max_t_inter_keys', max_tinter_key_polyf, 'total_nb_keys_pressed', num2cell(nb_keys), 'polyf_nb_keys', num2cell(nb_keys_polyf), 'typing_speed', typing_speed, 'nb_keys_interf', num2cell(nb_keys-nb_keys_polyf) );

POLYF=struct2table(POLYF);

