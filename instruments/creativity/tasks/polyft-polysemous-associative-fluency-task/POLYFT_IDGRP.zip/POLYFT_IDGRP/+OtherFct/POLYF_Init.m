%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com

% Required Psychtoolbox-3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global OSX_JAVA_GETCHAR;
% Is this Matlab? Is the JVM running? Isn't this Windows Vista or later?
if psychusejava('desktop') && ~IsWinVista
    if isempty(OSX_JAVA_GETCHAR)
        try
            OSX_JAVA_GETCHAR = AssignGetCharJava;
        catch %#ok<*CTCH>
            error('Could not load Java class GetCharJava! Read ''help PsychJavaTrouble'' for help.');
        end
        OSX_JAVA_GETCHAR.register;
    end
    if exist('commandwindow') 
        commandwindow;
    end

    osx=1;

elseif ~KbQueueReserve(3, 1, [])
    osx=0;
    LoadPsychHID;
    if ~KbQueueReserve(1, 1, [])
       error('Keyboard queue for default keyboard device already in use by KbQueue/KbEvent functions et al. Use of ListenChar/GetChar etc. and keyboard queues is mutually exclusive!');
    end

    % Got it. Allocate and start it:
    PsychHID('KbQueueCreate');
    PsychHID('KbQueueStart');

    if (IsOSX(1) || (IsOctave && IsGUI))
        PsychHID('KeyboardHelper', -14);
    end
else
    osx=0;
end

ListenChar(2);

Seed_is = rng('shuffle');


data_training=data_list(1:nb_items_training);
data_shuffled=data_list(nb_items_training+1:end);
data_shuffled=data_shuffled(randperm(nb_items_test));
data_shuffled = [data_training ; data_shuffled];

KbName('UnifyKeyNames');

key_delete={8};
if Language=="FR"
    kb_keys= num2cell([45 65:90 97:122 192:214 225:251]);
    key_enter={13, 32, 10};
else
    kb_keys= num2cell([32 45 65:90 97:122 192:214 225:251]);
    key_enter={13, 10};
end


target_rect =[0; fix(screenYpixels/2) - fix(screenYpixels/16)-fix(screenYpixels/20) ;screenXpixels; fix(screenYpixels/2)];
resp_rect = [0; fix(screenYpixels/2);screenXpixels; fix(screenYpixels/2)+fix(screenYpixels/16)];



