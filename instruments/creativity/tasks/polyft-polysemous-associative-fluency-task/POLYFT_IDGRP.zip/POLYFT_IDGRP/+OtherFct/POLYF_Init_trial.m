
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com

% Required Psychtoolbox-3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

WaitSecs(0.5);
enabled_keys=[cell2mat(kb_keys) cell2mat(key_delete) cell2mat(key_enter)];

RestrictKeysForKbCheck(enabled_keys)
target_word=data_shuffled{trial_polyf};
Screen('TextSize',window,50);


DisplayFct.FixationCross(TimeIB,NormalColor,window,screenXpixels, screenYpixels,xCenter, yCenter);
FlushEvents('keyDown')

Screen('FillRect',window,[0,0,0],target_rect);
DrawFormattedText2(target_word,'win',window,'baseColor',NormalColor, 'winRect',target_rect','sx','center','xalign','center','sy','center','yalign','center');
onset_polyf_=Screen('Flip', window,0,1);

limitTime_polyf_=onset_polyf_+Time2Wait;



idx_rep_polyf=1;
polyf_resp{idx_rep_polyf}='';
deleted_resp(idx_rep_polyf)={0};
polyf_start2write(idx_rep_polyf)={0};
polyf_t_validated(idx_rep_polyf)={NaN};
polyf_suppressed(idx_rep_polyf)={0};
target_polyf(idx_rep_polyf)={target_word};
consec_del=0;
keyspressed{idx_rep_polyf}='';
keyspolyf{idx_rep_polyf}='';
tstamps_keys{idx_rep_polyf}='';

t0=GetSecs();

secs=t0;

resp_=[];
FlushEvents('keyDown');
