%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Lucie Vigreux
% Contact: lucievigreux@gmail.com 

% Required Psychtoolbox-3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

RestrictKeysForKbCheck([]);
KbName('UnifyKeyNames');
pathInstru=['Lists/' char(task) '/Instructions/' char(Language) '/'];%Define where the instructions files are stored

Params=readtable("Params_table.xlsx",'Sheet',mode,'ReadRowNames',true);

Params=Params(task,:);
Time2Wait=Params.time_rep;
TimeIB=Params.time_inter_trial;


nb_items_training=Params.nb_Training;
nb_items_test=Params.nb_Test;
NumberItems=nb_items_test+nb_items_training;

if exist('task_','var')
    task=task_;
end



if Params.stim_type=="rd"
    pathList=['Lists/PolyF/WordLists/' char(Passa_Infos.STIM_List{strcmp(Passa_Infos.Task_Order,task)})];  
    data_list=table2array(readtable([pathList '.txt'],'FileEncoding',EncodingFile,'ReadVariableNames',0));
elseif Params.stim_type=="saved"
    load ("POLYF_resp.mat");
    data_list=POLYF_resp;
end

EnterBar=KbName('return'); %Obtain the key number of the Enter bar
Key2Enable=EnterBar; %Decide which key are enable during the task
TypeResp='keyboard'; %Decide the way to respond for the participants




 if exist([NameFolder '/' DateString '_' PNType task '_'  PN '_' Initials '_unfinished.mat'],'file')
    load([NameFolder '/' DateString '_' PNType task '_'  PN '_' Initials '_unfinished.mat']);
    OtherFct.Extract_Output
    status=Output.status;
    data_shuffled=Output.data_shuffled;
    Seed_is = Output.Seed;
else
    Seed_is = rng('shuffle');
    status=struct('suffix', '_unfinished');
    status.training=1;
    status.test=1;
end
