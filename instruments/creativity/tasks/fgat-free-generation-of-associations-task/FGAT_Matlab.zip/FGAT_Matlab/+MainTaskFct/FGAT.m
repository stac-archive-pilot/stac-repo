%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              FGAT_Task
% Version: 1
% Last Edited: 25/02/2026 by Aliz�e Lopez-Persem
% Contact: alizee.lopez-persem@icm-institute.org
%
% Description; This script will start the FGAT task 
% Input files required:
%           - The list of the cues (in creaflex_cleanX.mat)
%           - The instructions files (JPG in /instructions)
%           - The full folder of the task
%
% Required Psychtoolbox-3.
% Created on Matlab 2024b
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Safety check: re-open screen if window was closed between tasks
try
    windowValid = Screen('WindowKind', window) == 1;
catch
    windowValid = false;
end
if ~windowValid
    DisplayFct.ScreenStart;
end

disp('Loading...')

%% PARAMETERS
% Roots and lists
pathList    = ['Lists' filesep 'FGAT' filesep 'WordLists' filesep];%Define where the list of words are stored
stims = load([pathList 'creaflex_clean62.mat']);
NumberItems=length(stims.sub_resp);
training_list = {'oiseau','r�alit�','ailleurs','bureau','d�sert'};

% Dictionnary
load(['lists' filesep 'FGAT' filesep 'WordLists' filesep 'dico_fr.mat'])
dico_up = dico_mat;

% Key stuffs
RestrictKeysForKbCheck([]);
KbName('UnifyKeyNames');%Unify the keys across the different OS.
SpaceBar = [KbName('SPACE') KbName('ESCAPE') KbName('N')]; %Obtain the key number of the Space bar
FGATOptions.Key2Enable = SpaceBar; %Decide which key are enable during the task
FGATOptions.TypeResp   = 'keyboard'; %Decide the way to respond for the participants
FGATOptions.left_right = options.left_right;
FGATOptions.EscapeKey  = Escape_key;

% Time stuffs
FGATOptions.TimeThink       = 0.5; %Define the time to think before to respond
FGATOptions.TimeITI         = 0.5; %ITI before the next trial
FGATOptions.Time2Wait_Part1 = 10; %Specify time for participant to answer the trial for part 1
FGATOptions.Time2Wait_Part2 = 20; %Specify time for participant to answer the trial for part 2
FGATOptions.time_too_late   = 1.2;
FGATOptions.TimeToType      = 30;
FGATOptions.CrossDuration=2;

% Font sizes
FGATOptions.FontSizeInstruct = wordsFontSize; %Define the size of the font for the instructions
FGATOptions.FontSizeTrial    = wordsFontSize; %Define the size of the font for the cues words in the trials

% Colors
FGATOptions.NormalColor  = [0 255 255]; %Define the normal color for the word display (white)
FGATOptions.BackgroundWT = [0 0 0]; %Define the normal color for the background (black)
FGATOptions.BackgroundNT = [127 127 127]; %Define the color for the background before the end of the trial (grey)


%Shuffle the random seed
Seed_is = rng('shuffle');

%%TASK DESIGN
%create cue list.
FGAT_list   = stims.sub_resp(:,1);

%Shuffle the list randomly.
rand_order1=zeros(length(FGAT_list),1);
while length(unique(rand_order1))~= length(FGAT_list)
    rand_order1=randperm(length(FGAT_list));
end

FGAT_suffled  = FGAT_list(rand_order1);

%Create ouput variables for the two parts of the experiment.
Answer_FGAT   = num2cell(NaN(NumberItems,6));

%Store in the first column, the cues.
Answer_FGAT(:,1)  = FGAT_suffled(1:NumberItems);

%Silent the input from keyboard and hide the mouse
ListenChar(2);
HideCursor(screenNumber);

% DO FIRST OR DIST?
if do_first ==1
    name_task           = 'FGAT_FIRST';
    name_task_in_struct = 'FGAT_First';
    
    diapoTrain = 1:9;
    diapoTask  = 10;
    diapoEnd   = 11;
    
    Time2Wait = FGATOptions.Time2Wait_Part1;
    
else
    name_task           = 'FGAT_DIST';
    name_task_in_struct = 'FGAT_Dist';

    diapoTrain = 12:18;
    diapoTask  = 19;
    diapoEnd   = 20;

    Time2Wait = FGATOptions.Time2Wait_Part2;

end

% DO TRAINING OR TASK?
if do_training == 1
    suffix        = '_training';
    diapoStart    = diapoTrain;
    list_trials   = training_list;
else
    suffix        = '';
    diapoStart    = diapoTask;
    list_trials   = FGAT_suffled;
end

NumberItems  = length(list_trials);

name_taskOutput=[name_task suffix '_'];
results_output = [Created filesep name_taskOutput PNType PN '_' Initials '_temp.mat'];


%% RUN THE TASK

% Is there already some data??? If so, load them and don't do training
if exist(results_output,'file')
    load(results_output)
    
    existDat=OutputTemp.(name_task_in_struct);
    Answer_FGAT=existDat;
    starting_point = find(cellfun(@isnan,existDat(:,2)),1,'first');
    FGAT_suffled=existDat(:,1);
    list_trials   = FGAT_suffled;
    
    do_training=0;

else
    starting_point = 1;

end


%% FGAT TASK

%% INSTRUCTIONS
options.diapo_num = diapoStart;

[time_start,time_end,key_pressed]=DisplayFct.display_instructions_crehack(window,windowRect,Instru_root,options);
[ keyIsDown, keyTime, keyCode ] = KbCheck;
if keyIsDown && find(keyCode)==Escape_key
    OtherFct.escaping(window,options)
end

%% TASK

it = starting_point-1;
for WhichIterationFGAT = starting_point:NumberItems
    it = it+1;
    
       %% Beginning of trial: CROSS
        Screen('TextSize', window, 70);
        Screen('DrawText',window,'+',xCenter,yCenter,[255 255 255]);
        CrossTime=Screen(window,'flip');

        WaitSecs(FGATOptions.CrossDuration+randn(1)+0.5);
    
    %Store in a temporary variable, the current word to be display
    ListElements = list_trials{WhichIterationFGAT};
    %Display the trial and get the response of the participants
    
    OutputFGAT_trials=DisplayFct.DisplayTrial_Resp(ListElements,window,LeftScreenPosition,RightScreenPosition,[],[],...
        Time2Wait,FGATOptions);
    
    %Store the current response for the trial in the ouput variable
    Answer_FGAT{it,1}   = ListElements;
    Answer_FGAT(it,2:5) = OutputFGAT_trials(1:4);
    
    annonce{2} = Answer_FGAT{it,1};
    annonce{4} = Answer_FGAT{it,4};
    
    reply = annonce{4};
    
    % Check if response is known or not
    if ~strcmp(reply,'') && ~strcmp(reply,' ')
        
        if isempty(find(strcmpi(reply,dico_up), 1))
            Answer_FGAT{it,6} = 0;
            redo_FGAT = 0;
            reply_valid = 0;
        else
            reply_valid = 1;
            redo_FGAT = 0;
            Answer_FGAT{it,6} = 1;
        end
    else
        redo_FGAT = 0;
        reply_valid = 0;
    end
    if redo_FGAT ==1
        WaitSecs(0.05);
        [reply, Timing.TypingTiming]=DisplayFct.AskLimitTime(window,'R�ponse ? ',FGATOptions.NormalColor,FGATOptions.BackgroundWT,'GetChar','center','center',FGATOptions.FontSizeInstruct,5);
        Answer_FGAT{it,7}=Answer_FGAT{it,4};
        Answer_FGAT{it,4}=reply;
        Answer_FGAT{it,9}=Timing;
        
    end
    if OutputFGAT_trials{2}==0
        Screen(window,'DrawText','Trop tard !',xCenter,yCenter,[255 0 0]);
        Screen('Flip', window, 0, 0);
        WaitSecs(FGATOptions.time_too_late);
    end
    %Store in a variable, the first part
    Answer_FGAT{it,8}=OutputFGAT_trials(5);
    OutputTemp=struct('Seed',Seed_is,name_task_in_struct,{Answer_FGAT});
    
    %Save the responses in the newly created folder
    save(results_output,'OutputTemp');
    [ keyIsDown, keyTime, keyCode ] = KbCheck;
    if keyIsDown && find(keyCode)==Escape_key
        OtherFct.escaping(window,options)
        
    end
end
%%
%Store in a final variable, the responses of the participants
Output=struct('Seed',Seed_is,name_task_in_struct,{Answer_FGAT});

%Save the responses in the newly created folder
save(strrep(results_output,'_temp',''),'Output');
delete(results_output);

% if display_instruction==1
    if do_training == 0
        options.diapo_num = diapoEnd;
        [time_start,time_end,key_pressed]=DisplayFct.display_instructions_crehack(window,windowRect,Instru_root,options);
    end
% end
[ keyIsDown, keyTime, keyCode ] = KbCheck;
if keyIsDown && find(keyCode)==Escape_key
    OtherFct.escaping(window,options)
end

try
    ListenChar(0)
catch
    % Suppress PsychHID KbQueueStop errors on some Psychtoolbox versions
end

