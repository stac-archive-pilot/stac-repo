%%%%%%%%Screen start

%Call some default settings for setting up Psychtoolbox 
Screen('Preference', 'SkipSyncTests', 2);

% Get the screen numbers. This gives us a number for each of the screens
% attached to the computer.
screens = Screen('Screens');

% Draw on the output screen selected in the parameters
screenNumber = 0;% screens(1); %OutputScreen;

% Define black.
black = BlackIndex(screenNumber);

% Open a screen window
    PsychImaging('PrepareConfiguration');
    PsychImaging('AddTask','General','UseRetinaResolution');
    if ismac

    wordsFontSize=90;
else
    wordsFontSize=30;

end
[window, windowRect] = PsychImaging('OpenWindow',screenNumber, black);
    w_px = windowRect(3);
    h_px = windowRect(4);
% Get the size of the on screen window
[screenXpixels, screenYpixels] = Screen('WindowSize', window);

% Query the frame duration
ifi = Screen('GetFlipInterval', window);

% Get the center coordinate of the window
[xCenter, yCenter] = RectCenter(windowRect);
%Get the dimension on the screen
rect= [ 0 0 screenXpixels screenYpixels];

%Define the position where the words will be presented.
LeftScreenPosition=rect(3)*0.4;
RightScreenPosition=rect(3)*0.6;
TopScreenPosition=rect(4)*0.35;
BottomScreenPosition=rect(4)*0.6;

% [w, h] = RectSize(Screen('TextBounds', window, 'Loading...'));
Screen('DrawText', window, 'Loading...', xCenter, yCenter, [200 0 0]);
Screen(window,'flip');

    KbName('UnifyKeyNames');
