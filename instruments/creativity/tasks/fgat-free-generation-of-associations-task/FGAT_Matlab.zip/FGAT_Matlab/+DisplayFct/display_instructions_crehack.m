function [time_start,time_end,key_pressed]=display_instructions_crehack(scr,rect,ins_root,options)

time_start=clock;


% list_ins=dir([ins_root '*.jpeg']);
to_disp = options.diapo_num;
for id=1:length(to_disp)
    if to_disp(id)<10
    im{id}=imread([ins_root 'Diapositive0' num2str(to_disp(id)) '.JPG']);
    else
    im{id}=imread([ins_root 'Diapositive' num2str(to_disp(id)) '.JPG']);
        
    end
end

exit_ins=0;
p=1;
pp=0;
while exit_ins==0
    
    simc=size(im{p});
    if ismac
      simc=simc*2;
    end
    
    
    imrectc=[(rect(3)/2)-simc(2)/2,... % Position horizontale
        rect(4)/2-simc(1)/2,... % Position verticale
        (rect(3)/2)-simc(2)/2+simc(2),...
        rect(4)/2-simc(1)/2+simc(1)];
    
    Screen('PutImage', scr, im{p},imrectc);
    Screen(scr,'Flip');
    WaitSecs(.2);
    
    resp_ok=0;
    while resp_ok==0
        [~, keyCode] = KbWait;
        pp=pp+1;
        key_pressed{pp}=KbName(keyCode);
        if strcmpi(KbName(keyCode),options.left_right{2})
            p=p+1;
            resp_ok=1;
        elseif strcmpi(KbName(keyCode),options.left_right{1})
            p=p-1;
            resp_ok=1;
        elseif strcmpi(KbName(keyCode),options.escape_key)
            resp_ok=1;
            [w, h] = RectSize(Screen('TextBounds', scr, 'Escaping ? Y/N'));
            Screen('DrawText', scr, 'Escaping ? YES < / NO: >', w/2, h/2, [200 0 0]);
            Screen(scr,'flip');
            WaitSecs(0.1);
            FlushEvents;
            [~, keyCode] = KbWait;
            pp=pp+1;
            key_pressed{pp}=KbName(keyCode);
            if strcmpi(KbName(keyCode),options.left_right{1})
                error('user pressed escape');
                 exit_ins=1;

             elseif strcmpi(KbName(keyCode),options.left_right{2})
                 resp_ok=1;
                 pp=pp-1;
                
            end
        else
            resp_ok=0;
        end
    end
    
    if p==0
        p=1;
    end
    
    if p==id+1
        exit_ins=1;
    end
end

time_end=clock;



