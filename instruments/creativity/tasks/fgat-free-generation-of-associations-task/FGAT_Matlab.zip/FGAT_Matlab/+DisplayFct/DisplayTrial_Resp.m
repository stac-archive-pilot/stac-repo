function TempOutput=DisplayTrial_Resp(ListElements,window,LeftScreenPosition,RightScreenPosition,BottomScreenPosition,TopScreenPosition,Time2Wait,options)

%%%%%%%%%%%%%%%%
% Version: 1
% Last Edited: 23/10/2018
% Author: Matthieu Bernard
% Contact: matthieubernard@outlook.com
%
%INPUT: - ListElements: List with the word(s) for the current trial.
%       - window: The window in which the trial should be display.
%       - LeftScreenPosition: The left position of the word(s) to be
%       display
%       - RightScreenPosition: The right position of the word(s) to be
%       display
%       - BottomScreenPosition: The bottom position of the word(s) to be
%       display
%       - TopScreenPosition: The top position of the word(s) to be
%       display
%       - FontSizeTrial: The size to display the word(s).
%       - ColorWord: The colour of the word(s). [R G B]
%       - BackgroundWT: Colour of background at start of trial. [R G B]
%       - BackgroundNT: Colour of background after passed the Time2Wait
%       marker. [R G B]
%       - TimeThink: Time to think before the trial is count as null
%       - TimeITI: Time to wait between the trials.
%       - Time2Wait: Time to wait before change the colour of the screen.
%       - TypeResp: The type of responce that should be done ('keyboard' or
%       'Choice').
%       - WhichChoice: If for the TypeResp, 'Choice' is selected. This
%       variable contains the two keys used.
%       - Key2Enable: Which key of the keyboard that should be enable.
%
%OUTPUT: - TempOutput: List with the result of the current trial. C1:
%       reaction time to answer. | C2: If the participant gave an answer
%       before time limit | C3: the answer of the participant | C4: If the
%       TypeResp is 'keyboard', return time elapse while participant type
%       answer.
%
%Note: Need to have Psychtoolbox-3 installed.
%%%%%%%%%%%%%%%%

FontSizeTrial=options.FontSizeTrial;
ColorWord=options.NormalColor;
BackgroundWT=options.BackgroundWT;
BackgroundNT=options.BackgroundNT;
TimeThink=options.TimeThink;
TimeITI=options.TimeITI;
TypeResp=options.TypeResp;
Key2Enable=options.Key2Enable;
WhichChoice=[];
TimeLeft=options.TimeToType;

%%
%Restrict the key enabled for the task
RestrictKeysForKbCheck(Key2Enable);

%Check the type of response of the participants
if strcmp(TypeResp,'keyboard') %If use the keyboard
    TempOutput=cell(1,4); %Create the temporary output variable for the trial that will return the values
    WhichChoice=[]; %No need of choice for keyboard
elseif strcmp(TypeResp,'Choice') %if use a choice using two keys define by variable WhichChoice
    TempOutput=cell(1,3); %Create the temporary output variable for the trial that will return the values
    if isempty(WhichChoice) %If no choice specificy, return error
        error('No Choice implement! Check the parameters of task!')
    end
else %If no type of response specifiy, return error
    error('Wrong type of input responses! Check in parameters of task. Only "keyboard" & "Choice" implemented.')
end

%%
%Display the word(s) on the screen
DisplayFct.DisplayWords(ListElements,0,BackgroundWT,window,LeftScreenPosition,RightScreenPosition,BottomScreenPosition,TopScreenPosition,FontSizeTrial,ColorWord)
Timing.cueTime=GetSecs;

%Wait for x second to ensure the reading of the participants
WaitSecs(TimeThink);

%Display the word(s) on the screen

DisplayFct.DisplayWords(ListElements,0,BackgroundWT,window,LeftScreenPosition,RightScreenPosition,BottomScreenPosition,TopScreenPosition,FontSizeTrial,ColorWord);

%Get the time stamp at the start in order to evaluate the time limit
TimeStart = GetSecs;

%Set up the time out at false.
TimeOut = false;

%Repeat until participants answered or time limit
while ~TimeOut
    % Check if a key is pressed, only keys specified in RestrictedKeys are
    % considered valid
    [ keyIsDown, keyTime, keyCode ] = KbCheck;
    
    %If a key is down
    if(keyIsDown) && find(keyCode)~=options.EscapeKey
        if strcmp(TypeResp,'keyboard') %If the type of response is a keyboard
            %Get the time stamp when the participant start to write
            StartWritting=GetSecs;
            Timing.SpaceTime=StartWritting;

            %Limit the time to type the response to 5 seconds.
            %Ask to the participant to type his response using the keyboard
            %and catch the answer and store it.
            WaitSecs(0.2);

            [reply, Timing.TypingTiming]=DisplayFct.AskLimitTime(window,'R�ponse ? ',ColorWord,BackgroundWT,'GetChar','center','center',FontSizeTrial,TimeLeft);

            %Get the time stamp when the participant finish to write
            EndWritting=GetSecs;
             Timing.EnterTime=EndWritting;
            %Break the while loop
            break
            
        elseif strcmp(TypeResp,'Choice') %If the type of response is a choice
            %Check if the KeyPressed is one of the expected key stored in
            %which choice.
            if strcmp(KbName(find(keyCode)),WhichChoice{1}) %First choice
                %Then store the name of the key in a temporary variable
                KeyPressedTemp=WhichChoice{1};
            elseif strcmp(KbName(find(keyCode)),WhichChoice{2}) %Second choice
                %Then store the name of the key in a temporary variable
                KeyPressedTemp=WhichChoice{2};
            else %If not from the choice, store a missing value
                KeyPressedTemp='NONE';
            end
            break
        end
    elseif(keyIsDown) && find(keyCode)==options.EscapeKey
        escaping(window,options)
    end
    
    %Two seconds before the end, fill the screen in grey
    if( (keyTime - TimeStart) > Time2Wait-2)
        %Display the words of the screen but change the color
        %of the background to grey.
        DisplayFct.DisplayWords(ListElements,0,BackgroundNT,window,LeftScreenPosition,RightScreenPosition,BottomScreenPosition,TopScreenPosition,FontSizeTrial,ColorWord);
    end
    %If participant didn't anwer in time, retun no response and exit loop.
    if( (keyTime - TimeStart) > Time2Wait)
        TimeOut = true;
        reply=' ';
    end
end

%%
%Put the time of answer in the first column of the variable
TempOutput{1}=keyTime - TimeStart;

%Put in the second column whether the participant answered in time
if TimeOut
    GaveAnswer=0;
else
    GaveAnswer=1;
end
TempOutput{2}=GaveAnswer;

%Put the answer in the last column(s)
if strcmp(TypeResp,'keyboard') %If type of
    TempOutput{3}=(reply); %Put reply in upper case
    %If the answer where not given in correct time
    if TimeOut
        %Return empty variable
        TempOutput{4}=0;
    else
        %Return time participant take to write response.
        TempOutput{4}=EndWritting-StartWritting;
    end
    
elseif strcmp(TypeResp,'Choice') %If the type of response is a choice
    %If the answer where not given in correct time
    if TimeOut
        %Return NA value (i.e. null response)
        TempOutput{3}='NA';
    else
        %Return the key pressed
        TempOutput{3}=KeyPressedTemp;
    end
end
TempOutput{5}=Timing;
%ITI of x seconds
WaitSecs(TimeITI);

%Activate all keys
RestrictKeysForKbCheck([]);

end

function escaping(window,options)
[w, h] = RectSize(Screen('TextBounds', window, 'Escaping ? Y\N'));
Screen('DrawText', window, 'Escaping ? YES: Space \ NO: escape', w\2, h\2, [200 0 0]);
Screen(window,'flip');
WaitSecs(0.1);
FlushEvents;
[~, keyCode] = KbWait;
if strcmpi(KbName(keyCode),'SPACE')
    ListenChar(0)
    error('user pressed escape');
else
    FlushEvents;
end
end