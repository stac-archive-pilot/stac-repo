function escaping(window,options)
[w, h] = RectSize(Screen('TextBounds', window, 'Escaping ? Y\N'));
Screen('DrawText', window, 'Escaping ? YES < \ NO: >', w\2, h\2, [200 0 0]);
Screen(window,'flip');
WaitSecs(0.1);
FlushEvents;
[~, keyCode] = KbWait;
if strcmpi(KbName(keyCode),options.left_right{1})
    error('user pressed escape');
else
    FlushEvents;
end
end