function [reply] = KbCheck_accent(last)
RestrictKeysForKbCheck([]);

% clear KbCheck
FlushEvents;
if ismac
    codes_accents = [31 36 39  51 46 44    33 38 192 40      42    47];
    % %                �  �  �      m -  space '  �  �   return delete  ^
    codes_voyelles = [20 8 18 12 24];
    % %                 a  e  i  o  u
    qwerty = 'qwertyuiopasdfghjklzxcvbnm';
    
else
    codes_accents = [50 55 48  77 54 32    52 57 52  13      8       221];
    codes_voyelles = [65 69 73 79 85];
    qwerty = 'azertyuiopqsdfghjklwxcvbn';
    clear KbCheck
end
azerty = 'azertyuiopqsdfghjklwxcvbn';

KbName('UnifyKeyNames');

accents={'�','�','�','m','-',' ','''','�','�','Return','DELETE'};

get_second_char=0;
keyPressed = 0; % set this to zero until we receive a sensible keypress

% while keyPressed == 0 % hang the system until a response is given
%         keyIsDown='';
%           keyCode=zeros(256,1);


[ ~, keyCode , ~] = KbWait;



%     if sum(keyCode)~=0
keyPressed = find(keyCode);

if ismember(keyPressed,codes_accents(1:end-1))
    reply=accents{keyPressed==codes_accents};
elseif keyPressed == codes_accents(end) %(^)
    get_second_char = 1;
    
else
    
    reply = KbName(keyPressed(1));
    if  any(ismember(azerty,reply))
        reply=azerty(strfind(qwerty,reply));
    else
        reply = '';
    end
    
    %         end
    %         break
end
%
% end


FlushEvents('keyDown');

if get_second_char==1
    keyPressed2=0;
    while keyPressed2 == 0 % hang the system until a response is given
        
        [ ~, ~, keyCode2 ] = KbCheck;
        
        if sum(keyCode2)~=0
            if find(keyCode2)==codes_voyelles(1)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(2)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(4)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(3)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            elseif find(keyCode2)==codes_voyelles(5)
                
                reply='�';
                keyPressed2 = find(keyCode2);
                
            else
                keyPressed2=0;
            end
            
        end
    end
end

if (strcmp(last,'�') && strcmp(reply,'a')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'e')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'o')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'i')) || ...
        (strcmp(last,'�') &&  strcmp(reply,'u'))
    reply = '';
end

if exist('keyCode2','var')
    keyPressed3=1;
    
    FlushEvents;
else
    
    keyPressed3=0;
end

while keyPressed3 == 0 % hang the system until a response is given
    
    
    [ ~, ~, keyCode3] = KbCheck; % check for keypress
    
    if isempty(find(keyCode3))
        keyPressed3=1;
        
        break
    end
    
    try
        if find(keyCode3)~=find(keyCode)
            keyPressed3=1;
            
            break
        end
    end
    
    
    
    if strcmpi(reply,'Return')
        keyPressed3=1;
    end
    
end

