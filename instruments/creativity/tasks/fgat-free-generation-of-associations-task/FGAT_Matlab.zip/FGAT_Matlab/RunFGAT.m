% Main script to run the FGAT (initially associated with ratings as in
% CreHack (Lopez-Persem et al, American Psychologist 2024; Battistello et
% al, Comm Psy 2025; Moreno-Rodriguez et al, Comm Biol 2025)). The scripts
% has been simplified to contain only the FGAT task, by ALP on 25/02/2026.

clear
close all
clc

clear mex
do_CREHACK=1;


KbName('UnifyKeyNames')

Lang=1;

PN=input('Study code?','s');
Initials=input('Sub Number?','s');

PNType = 'Crehack_';
current = pwd;% '';
Created = [current filesep 'DATA' filesep PN '_' Initials];
mkdir(Created)

options.left_right={'LeftArrow','RightArrow'};
options.escape_key='Escape';

Instru_root = ['lists' filesep 'instructions' filesep];%Define where the instructions files are stored

Escape_key=KbName(options.escape_key);

Task_names={'FGAT_FIRST','FGAT_DIST'};
ListenChar(2);

% This is a security in case the task crashes and need to be restarted
for ff=1:length(Task_names)
    list_files{ff}=[Created filesep Task_names{ff} '_' PNType PN '_' Initials '.mat'];
    Training_files{ff}=[Created filesep Task_names{ff} '_training_' PNType PN '_' Initials '.mat'];
    if exist(list_files{ff},'file')
        done_tasks(ff)=1;
    else
        done_tasks(ff)=0;
    end
end


% Now define if last task was done entirely
if sum(done_tasks)==0
    starting_task=1;
else
    idx_last=find(done_tasks,1,'last');
        starting_task =idx_last+1;
end


if do_CREHACK ==1
    
    try

        
        what_to_run =1;% input('1: Run all, 2: Pick task(s)');
        if what_to_run == 1
            step = starting_task:ff;
        end
        
        DisplayFct.ScreenStart;
        RestrictKeysForKbCheck([]);
        HideCursor(screenNumber);
        
        for s=1:length(step)
            
    WaitSecs(.2);
    
    
            idxTask=[];
            idx_FIRST=strfind(Task_names{step(s)},'_FIRST');
            idx_DIST=strfind(Task_names{step(s)},'_DIST');

            if ~isempty(idx_FIRST)
                do_first = 1;
                do_dist = 0;
            elseif ~isempty(idx_DIST)
                do_first = 0;
                do_dist = 1;
            end
           
            if exist(Training_files{step(s)},'file')
                do_training=0;
                do_task=1;
            else
                do_training=1;
                do_task=1;
            end
            idxTask=[idx_FIRST idx_DIST]-1;
            
            if isempty(idxTask)
                idxTask=length(Task_names{step(s)});
                
            end
            if do_training==1
                MainTaskFct.(Task_names{step(s)}(1:idxTask));
                do_training=0;
            end
            if do_task==1
                do_training=0;
                MainTaskFct.(Task_names{step(s)}(1:idxTask));
                
            end
        end
        sca
        ListenChar()

    catch ME
        sca
        ListenChar()

        rethrow(ME)
        
        
    end
    
end
    