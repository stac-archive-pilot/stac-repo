# FGAT — Free Generation Association Task

**Authors:** Alizée Lopez-Persem (alizee.lopez-persem@icm-institute.org), Matthieu Bernard
**Last updated:** 25/02/2026
**Language:** MATLAB (Psychtoolbox-3, tested on MATLAB 2024b, macOS)
**Stimulus language:** French

**References:**
- Lopez-Persem et al., *American Psychologist* (2024)
- Battistello et al., *Communications Psychology* (2025)
- Moreno-Rodriguez et al., *Communications Biology* (2025)

---

## Overview

The FGAT is a computerised word association task that measures semantic associative processes by asking participants to produce a single word in response to a visually presented cue word. It comprises **two successive subtasks** that tap distinct associative modes.

---

## Subtasks

### 1. FGAT_FIRST — First (immediate) association

Participants see a cue word and must produce the **first word that comes to mind**, without reflection and as fast as possible.

- Time limit: **10 seconds**
- Captures **automatic / dominant associations**

### 2. FGAT_DIST — Distant (creative) association

Participants see the same cue words but must produce a word that is **not typically associated** with the cue, while still being meaningfully related. The association should be original, unusual, and surprising, yet comprehensible to someone else.

- Time limit: **20 seconds**
- Measures the capacity to generate **creative / distant associations** — 

---

## Stimuli

- **62 French cue words** (main experiment), randomly shuffled per participant — `lists/FGAT/WordLists/creaflex_clean62.mat` (Lopez-Persem et al, 2024; Moreno-Rodriguez et al, 2025)
- **30-item version** also available — `lists/FGAT/WordLists/creaflex_clean30.mat` (Battistello et al, 2025)
- Response validation performed online against a French dictionary — `lists/FGAT/WordLists/dico_fr.mat`
- **5 training words:** oiseau, réalité, ailleurs, bureau, désert

---

## Trial Structure

```
Fixation cross (2 s + jitter ~N(0,1)+0.5 s)
    ↓
Cue word displayed on screen (cyan on black)
    ↓
Participant presses SPACEBAR when a word comes to mind
    ↓
Prompt "Réponse ?" — participant types their response
    ↓
ENTER to submit  |  Screen turns grey 2 s before time-out
```

**Note:** If the participant does not press spacebar within the time limit, the trial is counted as a timeout and the response is not recorded. Responses not found in the French dictionary are flagged (validity = 0) but still retained.

---

## Output Variables

Responses are saved per participant in `DATA/<PN>_<Initials>/` as `.mat` files.
Each output cell array contains one row per trial with the following columns:

| Column | Content |
|--------|---------|
| 1 | Cue word |
| 2 | Reaction time (cue onset → spacebar press, in seconds) |
| 3 | Response given in time? (1 = yes, 0 = timeout) |
| 4 | Typed response word |
| 5 | Typing duration (spacebar → Enter, in seconds) |
| 6 | Dictionary validity of response (1 = valid French word, 0 = unknown) |
| 8 | Full timing structure (cue time, spacebar time, Enter time, per-letter timestamps) |

Two output files are created per subtask:
- `FGAT_FIRST_training_<...>.mat` / `FGAT_DIST_training_<...>.mat` — training phase
- `FGAT_FIRST_<...>.mat` / `FGAT_DIST_<...>.mat` — main task

A temporary `_temp.mat` file is written after every trial for crash recovery and deleted upon clean completion.

---

## Task Parameters

| Parameter | Value |
|-----------|-------|
| Fixation cross duration | 2 s + N(0,1)+0.5 s jitter |
| Think time before response window | 0.5 s |
| ITI (after response) | 0.5 s |
| Time limit — FIRST | 10 s |
| Time limit — DIST | 20 s |
| Grey-screen warning before timeout | 2 s before limit |
| Max typing time | 30 s |
| Cue word colour | Cyan [0 255 255] |
| Background colour | Black [0 0 0] |
| Warning background colour | Grey [127 127 127] |

---

## File Structure

```
FGAT_Matlab/
├── RunFGAT.m                        # Entry-point script
├── README.md                        # This file
├── +MainTaskFct/
│   └── FGAT.m                       # Core task logic
├── +DisplayFct/
│   ├── ScreenStart.m                # Psychtoolbox window initialisation
│   ├── DisplayTrial_Resp.m          # Single-trial display and response collection
│   ├── DisplayWords.m               # Word rendering on screen
│   ├── AskLimitTime.m               # Time-limited keyboard input
│   └── display_instructions_crehack.m  # Instruction slide display
├── +OtherFct/
│   ├── KbCheck_accent.m             # Keyboard input with French accent support
│   └── escaping.m                   # Escape handler
├── 
└── lists/
    └── instructions/
│   	├── Diapositive01–11.JPG         # Instruction slides for FGAT_FIRST
│   	└── Diapositive12–20.JPG         # Instruction slides for FGAT_DISTFGAT/
    └── FGAT/
	└──WordLists/
            ├── creaflex_clean62.mat # 62 cue words (main)
            ├── creaflex_clean30.mat # 30 cue words (short version)
            ├── dico_fr.mat          # French dictionary
            └── dico_fr_up.mat       # Extended French dictionary
```

---

## How to Run

1. Open MATLAB and set the working directory to the `FGAT_Matlab/` folder.
2. Run `RunFGAT.m`.
3. Enter the **study code** and **participant number** when prompted.
4. The script will run FGAT_FIRST, then FGAT_DIST automatically.
5. If the task crashes, re-running will detect existing output files and resume from where it left off (training is skipped if already completed; trials already saved are restored).

**Requirements:** Psychtoolbox-3, MATLAB 2020 or later.

---

## Participant Instructions (exact text, French)

### FGAT_FIRST — Slides 1 to 11

**Slide 01**
> Merci de participer !
>
> Pendant cette expérience, vous allez réaliser deux tâches. Avant chacune d'entre elles, les instructions s'afficheront à l'écran et vous ferez un petit entraînement.

**Slide 02**
> Lors de la première tâche, à chaque nouvel essai, vous allez voir apparaître un mot à l'écran :
>
> *(example word displayed on screen: bijou)*

**Slide 03**
> Vous devrez indiquer quel est le **premier mot qui vous vient à l'esprit**, sans réfléchir et le plus rapidement possible.
>
> *(example word displayed on screen: bijou)*

**Slide 04**
> Vous devrez indiquer quel est le **premier mot qui vous vient à l'esprit**, sans réfléchir et le plus rapidement possible.
>
> Dès que vous avez un mot à l'esprit, appuyez sur « espace ».
>
> *(example word displayed on screen: bijou)*

**Slide 05**
> Le mot « réponse ? » s'affiche alors à l'écran, utilisez les touches du clavier pour taper votre réponse.
>
> *(prompt displayed on screen: Réponse ?)*

**Slide 06**
> Le mot « réponse ? » s'affiche alors à l'écran, utilisez les touches du clavier pour taper votre réponse.
>
> Appuyez sur « Entrée » pour valider votre réponse.
>
> *(prompt displayed on screen: Réponse ?)*

**Slide 07**
> Une fois votre réponse validée, un nouveau mot apparaîtra à l'écran, procédez de la même façon.
>
> *(example word displayed on screen: chèvre)*

**Slide 08**
> **Attention !**
>
> - Attendez d'avoir une réponse en tête avant d'appuyer sur « espace »
> - Vous disposez de 10 secondes pour répondre
> - Si vous mettez trop de temps à taper votre réponse, elle ne sera pas comptabilisée
> - Les verbes conjugués, les noms propres et les groupes de mots ne sont pas acceptés

**Slide 09**
> Faisons un petit entraînement…

**Slide 10**
> Avez-vous des questions ?
> Sinon, démarrons le test.

**Slide 11**
> Merci !
>
> Prêt.e pour la tâche suivante ?

---

### FGAT_DIST — Slides 12 to 20

**Slide 12**
> Comme dans la tâche précédente, à chaque nouvel essai, vous allez voir apparaître un mot à l'écran :
>
> *(example word displayed on screen: bijou)*

**Slide 13**
> Cette fois, vous devrez répondre **un mot qui n'est habituellement pas associé** au mot présenté, mais qui lui est tout de même lié.
>
> *(example word displayed on screen: bijou)*

**Slide 14**
> Cette fois, vous devrez répondre **un mot qui n'est habituellement pas associé** au mot présenté, mais qui lui est tout de même lié.
>
> Pensez créativement : L'association entre le mot proposé et votre réponse doit être **originale**, **inhabituelle**, **surprenante**, tout en étant **compréhensible** pour quelqu'un d'autre.
>
> *(example word displayed on screen: bijou)*

**Slide 15**
> Cette fois, vous devrez répondre **un mot qui n'est habituellement pas associé** au mot présenté, mais qui lui est tout de même lié.
>
> Dès que vous avez un mot à l'esprit, appuyez sur « espace ».
>
> *(example word displayed on screen: bijou)*

**Slide 16**
> Le mot « réponse ? » s'affiche alors à l'écran, utilisez les touches du clavier pour taper votre réponse.
>
> Appuyez sur « Entrée » pour valider votre réponse.
>
> *(prompt displayed on screen: Réponse ?)*

**Slide 17**
> **Attention !**
>
> - Vous disposez de 20 secondes pour répondre
> - Si vous mettez trop de temps à taper votre réponse, elle ne sera pas comptabilisée
> - Les verbes conjugués, les noms propres et les groupes de mots ne sont pas acceptés

**Slide 18**
> Faisons un petit entraînement…

**Slide 19**
> Avez-vous des questions ?
> Sinon, démarrons le test.

**Slide 20**
> Merci !
>
> Prêt.e pour la tâche suivante ?
