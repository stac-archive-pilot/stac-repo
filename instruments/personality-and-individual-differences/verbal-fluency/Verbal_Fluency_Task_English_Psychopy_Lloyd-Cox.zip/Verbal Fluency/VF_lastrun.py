﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.5),
    on June 14, 2023, at 15:02
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.5'
expName = 'VerbalFluency'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\james\\Documents\\ZDesktop\\PhD\\Misc\\SfNC\\Verbal Fluency\\VF_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1536, 864], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "VFinstrux" ---
instrux = visual.TextStim(win=win, name='instrux',
    text='Well done so far.\n\nIn the next task, you will be given a category, and you must type as many items from that category as you can. \n\nFor instance, if the category is "words beginning with F" you should type as many words that begin with F as you can.',
    font='Arial',
    pos=(0, 0.1), height=0.035, wrapWidth=1.2, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
EntertoContinue = visual.TextStim(win=win, name='EntertoContinue',
    text='Press ENTER to continue',
    font='Arial',
    pos=(0, -.35), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "VFinstrux_2" ---
intrux_2 = visual.TextStim(win=win, name='intrux_2',
    text='Do not enter the same item twice, or the same root word with different suffixes (e.g., if you list "fox", do not list "foxes" in the same round).\n\nYou will have 60 seconds to type as many items from the category as you can. Press ENTER after typing each word.\n\nThere will be 3 categories in total.',
    font='Arial',
    pos=(0, 0.1), height=0.035, wrapWidth=1.2, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
EntertoContinue_2 = visual.TextStim(win=win, name='EntertoContinue_2',
    text='Press ENTER to begin',
    font='Arial',
    pos=(0, -.35), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp = keyboard.Keyboard()

# --- Initialize components for Routine "getreadyVF" ---
InstruxVF_2 = visual.TextStim(win=win, name='InstruxVF_2',
    text='Type as many words as you can that are in the category shown. Press ENTER after each word. ',
    font='Arial',
    pos=(0, .25), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
text_2 = visual.TextStim(win=win, name='text_2',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.15, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "VF" ---
VFrespbox = visual.Rect(
    win=win, name='VFrespbox',
    width=(0.45, 0.17)[0], height=(0.45, 0.17)[1],
    ori=0, pos=(0, -0.22), anchor='center',
    lineWidth=1,     colorSpace='rgb',  lineColor=[1,1,1], fillColor=[1,1,1],
    opacity=1, depth=0.0, interpolate=True)
InstruxVF = visual.TextStim(win=win, name='InstruxVF',
    text='Type as many words as you can that are in the category shown. Press ENTER after each word. ',
    font='Arial',
    pos=(0, .25), height=0.03, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
VFResp = visual.TextStim(win=win, name='VFResp',
    text='',
    font='Arial',
    pos=(0, -0.22), height=0.05, wrapWidth=0.48, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
VFcueDisp = visual.TextStim(win=win, name='VFcueDisp',
    text='',
    font='Arial',
    pos=(0, 0), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
# Run 'Begin Experiment' code from VFcode

import math

countdownStarted = False
CAPS=False
timeText_1 = visual.TextStim(win=win, name='timeText_1',
    text='',
    font='Arial',
    pos=(0.5, -0.3), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-5.0);
key_respVF = keyboard.Keyboard()

# --- Initialize components for Routine "NextTrialVF" ---
# Run 'Begin Experiment' code from code_13

keeptracknumind=0
intrux_14 = visual.TextStim(win=win, name='intrux_14',
    text='Press ENTER to begin the next trial.',
    font='Arial',
    pos=(0, 0), height=0.035, wrapWidth=1.2, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_20 = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "VFinstrux" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
_key_resp_2_allKeys = []
# Run 'Begin Routine' code from code

EscapeAllowed = True
win.mouseVisible = False
VFtime=60

# keep track of which components have finished
VFinstruxComponents = [instrux, EntertoContinue, key_resp_2]
for thisComponent in VFinstruxComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "VFinstrux" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instrux* updates
    if instrux.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instrux.frameNStart = frameN  # exact frame index
        instrux.tStart = t  # local t and not account for scr refresh
        instrux.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instrux, 'tStartRefresh')  # time at next scr refresh
        instrux.setAutoDraw(True)
    
    # *EntertoContinue* updates
    if EntertoContinue.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        EntertoContinue.frameNStart = frameN  # exact frame index
        EntertoContinue.tStart = t  # local t and not account for scr refresh
        EntertoContinue.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(EntertoContinue, 'tStartRefresh')  # time at next scr refresh
        EntertoContinue.setAutoDraw(True)
    
    # *key_resp_2* updates
    waitOnFlip = False
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=['return'], waitRelease=False)
        _key_resp_2_allKeys.extend(theseKeys)
        if len(_key_resp_2_allKeys):
            key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
            key_resp_2.rt = _key_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in VFinstruxComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "VFinstrux" ---
for thisComponent in VFinstruxComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "VFinstrux" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "VFinstrux_2" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
key_resp.keys = []
key_resp.rt = []
_key_resp_allKeys = []
# keep track of which components have finished
VFinstrux_2Components = [intrux_2, EntertoContinue_2, key_resp]
for thisComponent in VFinstrux_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "VFinstrux_2" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *intrux_2* updates
    if intrux_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        intrux_2.frameNStart = frameN  # exact frame index
        intrux_2.tStart = t  # local t and not account for scr refresh
        intrux_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(intrux_2, 'tStartRefresh')  # time at next scr refresh
        intrux_2.setAutoDraw(True)
    
    # *EntertoContinue_2* updates
    if EntertoContinue_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        EntertoContinue_2.frameNStart = frameN  # exact frame index
        EntertoContinue_2.tStart = t  # local t and not account for scr refresh
        EntertoContinue_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(EntertoContinue_2, 'tStartRefresh')  # time at next scr refresh
        EntertoContinue_2.setAutoDraw(True)
    
    # *key_resp* updates
    waitOnFlip = False
    if key_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        key_resp.frameNStart = frameN  # exact frame index
        key_resp.tStart = t  # local t and not account for scr refresh
        key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp.status == STARTED and not waitOnFlip:
        theseKeys = key_resp.getKeys(keyList=['return'], waitRelease=False)
        _key_resp_allKeys.extend(theseKeys)
        if len(_key_resp_allKeys):
            key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
            key_resp.rt = _key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in VFinstrux_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "VFinstrux_2" ---
for thisComponent in VFinstrux_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "VFinstrux_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
VFtrials = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('VFconds.xlsx'),
    seed=None, name='VFtrials')
thisExp.addLoop(VFtrials)  # add the loop to the experiment
thisVFtrial = VFtrials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisVFtrial.rgb)
if thisVFtrial != None:
    for paramName in thisVFtrial:
        exec('{} = thisVFtrial[paramName]'.format(paramName))

for thisVFtrial in VFtrials:
    currentLoop = VFtrials
    # abbreviate parameter names if possible (e.g. rgb = thisVFtrial.rgb)
    if thisVFtrial != None:
        for paramName in thisVFtrial:
            exec('{} = thisVFtrial[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "getreadyVF" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    getreadyVFComponents = [InstruxVF_2, text_2]
    for thisComponent in getreadyVFComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "getreadyVF" ---
    while continueRoutine and routineTimer.getTime() < 3.5:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *InstruxVF_2* updates
        if InstruxVF_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            InstruxVF_2.frameNStart = frameN  # exact frame index
            InstruxVF_2.tStart = t  # local t and not account for scr refresh
            InstruxVF_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(InstruxVF_2, 'tStartRefresh')  # time at next scr refresh
            InstruxVF_2.setAutoDraw(True)
        if InstruxVF_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > InstruxVF_2.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                InstruxVF_2.tStop = t  # not accounting for scr refresh
                InstruxVF_2.frameNStop = frameN  # exact frame index
                InstruxVF_2.setAutoDraw(False)
        
        # *text_2* updates
        if text_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            text_2.frameNStart = frameN  # exact frame index
            text_2.tStart = t  # local t and not account for scr refresh
            text_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
            text_2.setAutoDraw(True)
        if text_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_2.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                text_2.tStop = t  # not accounting for scr refresh
                text_2.frameNStop = frameN  # exact frame index
                text_2.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in getreadyVFComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "getreadyVF" ---
    for thisComponent in getreadyVFComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-3.500000)
    
    # set up handler to look after randomisation of conditions etc
    VFresps = data.TrialHandler(nReps=100, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='VFresps')
    thisExp.addLoop(VFresps)  # add the loop to the experiment
    thisVFresp = VFresps.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisVFresp.rgb)
    if thisVFresp != None:
        for paramName in thisVFresp:
            exec('{} = thisVFresp[paramName]'.format(paramName))
    
    for thisVFresp in VFresps:
        currentLoop = VFresps
        # abbreviate parameter names if possible (e.g. rgb = thisVFresp.rgb)
        if thisVFresp != None:
            for paramName in thisVFresp:
                exec('{} = thisVFresp[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "VF" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        VFcueDisp.setText(VFcond)
        # Run 'Begin Routine' code from VFcode
        shift_flag = False
        Resptext = ''
        RT1stKP=0
        
        RTLastKP=0
        
        if not countdownStarted:
            startTime=globalClock.getTime()
            #timeText="03:00"
            countdownStarted=True
            
        event.clearEvents('keyboard')
        key_respVF.keys = []
        key_respVF.rt = []
        _key_respVF_allKeys = []
        # keep track of which components have finished
        VFComponents = [VFrespbox, InstruxVF, VFResp, VFcueDisp, timeText_1, key_respVF]
        for thisComponent in VFComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "VF" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *VFrespbox* updates
            if VFrespbox.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                VFrespbox.frameNStart = frameN  # exact frame index
                VFrespbox.tStart = t  # local t and not account for scr refresh
                VFrespbox.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(VFrespbox, 'tStartRefresh')  # time at next scr refresh
                VFrespbox.setAutoDraw(True)
            
            # *InstruxVF* updates
            if InstruxVF.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                InstruxVF.frameNStart = frameN  # exact frame index
                InstruxVF.tStart = t  # local t and not account for scr refresh
                InstruxVF.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(InstruxVF, 'tStartRefresh')  # time at next scr refresh
                InstruxVF.setAutoDraw(True)
            
            # *VFResp* updates
            if VFResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                VFResp.frameNStart = frameN  # exact frame index
                VFResp.tStart = t  # local t and not account for scr refresh
                VFResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(VFResp, 'tStartRefresh')  # time at next scr refresh
                VFResp.setAutoDraw(True)
            if VFResp.status == STARTED:  # only update if drawing
                VFResp.setText(Resptext, log=False)
            
            # *VFcueDisp* updates
            if VFcueDisp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                VFcueDisp.frameNStart = frameN  # exact frame index
                VFcueDisp.tStart = t  # local t and not account for scr refresh
                VFcueDisp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(VFcueDisp, 'tStartRefresh')  # time at next scr refresh
                VFcueDisp.setAutoDraw(True)
            # Run 'Each Frame' code from VFcode
            keys = event.getKeys()
            n=len(keys)
            i=0
            
            
            ###Timer#####
            Diff=globalClock.getTime()-startTime
            timeRemaining = VFtime-math.floor(Diff/1) #this gives us a whole number for time 
            #remaining, using floor not round since we do not want the seconds to update except when the timeremaining crosses an actual whole integer
            Minutes = int(timeRemaining/60.0) # the integer number of minutes
            Seconds = int(timeRemaining - (Minutes * 60.0))
            if Minutes<10:
                minstring='0' + str(Minutes)
            else:
                minstring=str(Minutes)
            if Seconds<10:
                secstring='0' + str(Seconds)
            else:
                secstring=str(Seconds)
            timeText = minstring + ':' + secstring # create a string of characters representing the time
            
            
            ###### Text entry #####
            while i < n: # len(keys):
                if keys[i] == 'return' and len(Resptext)>=1 or timeRemaining<= 0:
                    continueRoutine = False
                    break
                elif keys[i] == 'escape' and EscapeAllowed == True:
                    continueRoutine = False
                    core.quit()
                    break
                elif keys[i] == 'space' :
                    Resptext += " "
                    i += 1
                elif keys[i] == 'backspace' :
                    Resptext = Resptext[:-1]
                    i += 1
                elif keys[i] == 'capslock' :
                    if CAPS==True:
                        CAPS= False
                    elif CAPS==False:
                        CAPS=True
                    i += 1
                elif keys[i] == 'period'and len(Resptext) < 80:
                    Resptext += "."
                    i += 1
                elif keys[i] == 'minus' and len(Resptext) < 80:
                    Resptext += "-"
                    i += 1
                elif keys[i] == 'comma' and len(Resptext) < 80: 
                    Resptext += ","
                    i = i + 1
                elif keys[i] in ['lshift', 'rshift']:
                    shift_flag = True
                    i = i + 1
                elif keys[i] == 'semicolon' and len(Resptext) < 80:
                    if shift_flag == False:
                        Resptext += ";"
                    else:
                        Resptext += ":"
                        shift_flag = False
                    i += 1
                elif keys[i] == 'apostrophe' and len(Resptext) < 80:
                    if shift_flag == False:
                        Resptext += "'"
                    else:
                        Resptext += '"'
                    i += 1
                elif keys[i] == 'slash' and len(Resptext) < 80:
                    if shift_flag == False:
                        Resptext += "/"
                    else:
                        Resptext += '?'
                        shift_flag = False
                    i = i + 1
                elif keys[i] == '1' and len(Resptext) < 80 and shift_flag == True:
                    Resptext += "!"
                    shift_flag = False
                    i = i + 1
                else:
                    if len(Resptext) < 80 and len(keys[i])==1:
                        Key=keys[i]
                        if CAPS or shift_flag:
                            Resptext += Key.upper()
                            shift_flag=False
                        else:
                            Resptext += Key
                    i += 1
            
            if timeRemaining <= 0:
                VFresps.finished = True
                continueRoutine = False
                countdownStarted = False
             
            
            # *timeText_1* updates
            if timeText_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                timeText_1.frameNStart = frameN  # exact frame index
                timeText_1.tStart = t  # local t and not account for scr refresh
                timeText_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(timeText_1, 'tStartRefresh')  # time at next scr refresh
                timeText_1.setAutoDraw(True)
            if timeText_1.status == STARTED:  # only update if drawing
                timeText_1.setText(timeText, log=False)
            
            # *key_respVF* updates
            waitOnFlip = False
            if key_respVF.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_respVF.frameNStart = frameN  # exact frame index
                key_respVF.tStart = t  # local t and not account for scr refresh
                key_respVF.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_respVF, 'tStartRefresh')  # time at next scr refresh
                key_respVF.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_respVF.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_respVF.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_respVF.status == STARTED and not waitOnFlip:
                theseKeys = key_respVF.getKeys(keyList=None, waitRelease=False)
                _key_respVF_allKeys.extend(theseKeys)
                if len(_key_respVF_allKeys):
                    key_respVF.keys = [key.name for key in _key_respVF_allKeys]  # storing all keys
                    key_respVF.rt = [key.rt for key in _key_respVF_allKeys]
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in VFComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "VF" ---
        for thisComponent in VFComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # Run 'End Routine' code from VFcode
        #extract the 1st and last key presses
        if len(key_respVF.rt)>0:
            RT1stKP=key_respVF.rt[0]
            RTLastKP=key_respVF.rt[-1]
        
        #save the data for this trial
        thisExp.addData("VFresp", Resptext)
        thisExp.addData("VFRT1stKP", RT1stKP)
        thisExp.addData("VFRTLastKP", RTLastKP)
        Resptext = ''
        
        
        # check responses
        if key_respVF.keys in ['', [], None]:  # No response was made
            key_respVF.keys = None
        VFresps.addData('key_respVF.keys',key_respVF.keys)
        if key_respVF.keys != None:  # we had a response
            VFresps.addData('key_respVF.rt', key_respVF.rt)
        # the Routine "VF" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 100 repeats of 'VFresps'
    
    
    # --- Prepare to start Routine "NextTrialVF" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from code_13
    
    keeptracknumind+=1
    if keeptracknumind==3:
        continueRoutine=False
        
    blahtext=str(keeptracknumind)
    key_resp_20.keys = []
    key_resp_20.rt = []
    _key_resp_20_allKeys = []
    # keep track of which components have finished
    NextTrialVFComponents = [intrux_14, key_resp_20]
    for thisComponent in NextTrialVFComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "NextTrialVF" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *intrux_14* updates
        if intrux_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            intrux_14.frameNStart = frameN  # exact frame index
            intrux_14.tStart = t  # local t and not account for scr refresh
            intrux_14.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(intrux_14, 'tStartRefresh')  # time at next scr refresh
            intrux_14.setAutoDraw(True)
        
        # *key_resp_20* updates
        waitOnFlip = False
        if key_resp_20.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            key_resp_20.frameNStart = frameN  # exact frame index
            key_resp_20.tStart = t  # local t and not account for scr refresh
            key_resp_20.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_20, 'tStartRefresh')  # time at next scr refresh
            key_resp_20.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_20.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_20.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_20.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_20.getKeys(keyList=['return'], waitRelease=False)
            _key_resp_20_allKeys.extend(theseKeys)
            if len(_key_resp_20_allKeys):
                key_resp_20.keys = _key_resp_20_allKeys[-1].name  # just the last key pressed
                key_resp_20.rt = _key_resp_20_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in NextTrialVFComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "NextTrialVF" ---
    for thisComponent in NextTrialVFComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "NextTrialVF" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'VFtrials'


# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
